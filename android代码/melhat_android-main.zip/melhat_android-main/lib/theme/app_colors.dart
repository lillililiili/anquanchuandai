import 'package:flutter/material.dart';

/// 春天色系颜色定义
/// 包含明亮主题和暗色主题的所有颜色
class SpringColors {
  SpringColors._();

  // ==================== 主题色 ====================
  /// 薄荷绿 - 主色调
  static const Color mintGreen = Color(0xFF10B981);
  static const Color mintGreenLight = Color(0xFF34D399);
  static const Color mintGreenDark = Color(0xFF059669);

  /// 天蓝色 - 次要色调
  static const Color skyBlue = Color(0xFF3B82F6);
  static const Color skyBlueLight = Color(0xFF60A5FA);
  static const Color skyBlueDark = Color(0xFF2563EB);

  /// 嫩芽黄 - 强调色
  static const Color sproutYellow = Color(0xFFF59E0B);
  static const Color sproutYellowLight = Color(0xFFFBBF24);
  static const Color sproutYellowDark = Color(0xFFD97706);

  /// 樱桃红 - 告警/危险色
  static const Color cherryRed = Color(0xFFDC2626);
  static const Color cherryRedLight = Color(0xFFEF4444);
  static const Color cherryRedDark = Color(0xFFB91C1C);

  // ==================== 背景色 ====================
  /// 明亮主题背景
  static const Color backgroundLight = Color(0xFFF9FBF9);
  static const Color homeBackgroundLight = Color(0xFFF5F6FA);
  static const Color cardBackgroundLight = Color(0xFFFFFFFF);

  /// 暗色主题背景
  static const Color backgroundDark = Color(0xFF121212);
  static const Color surfaceDark = Color(0xFF1E1E1E);
  static const Color cardBackgroundDark = Color(0xFF2C2C2C);

  // ==================== 文字颜色 ====================
  /// 明亮主题文字
  static const Color textPrimaryLight = Color(0xFF1F2937);
  static const Color textSecondaryLight = Color(0xFF4B5563);
  static const Color textTertiaryLight = Color(0xFF6B7280);
  static const Color textDisabledLight = Color(0xFF9CA3AF);

  /// 暗色主题文字
  static const Color textPrimaryDark = Color(0xFFFFFFFF);
  static const Color textSecondaryDark = Color(0xFFB0B0B0);
  static const Color textTertiaryDark = Color(0xFF808080);
  static const Color textDisabledDark = Color(0xFF606060);

  // ==================== 功能色 ====================
  /// 告警类型颜色
  static const Color alarmSOS = Color(0xFFDC2626);
  static const Color alarmFall = Color(0xFFF59E0B);
  static const Color alarmGeoFence = Color(0xFF8B5CF6);
  static const Color alarmLowBattery = Color(0xFF6B7280);

  /// 快捷操作颜色
  static const Color actionCheckIn = Color(0xFF10B981);
  static const Color actionMonitor = Color(0xFF3B82F6);
  static const Color actionIntercom = Color(0xFF8B5CF6);
  static const Color actionTrack = Color(0xFFF59E0B);
  static const Color actionFence = Color(0xFFEF4444);
  static const Color actionAlarm = Color(0xFFEC4899);

  // ==================== 其他 UI 元素 ====================
  /// 分割线
  static const Color dividerLight = Color(0x14000000); // ~0.08 alpha
  static const Color dividerDark = Color(0x1FFFFFFF);

  /// 图标背景 alpha 值
  static const double iconBackgroundAlpha = 0.1;
  static const double iconBackgroundAlphaActive = 0.15;

  // ==================== 暗色主题适配色 ====================
  /// 暗色主题下的主题色（降低饱和度）
  static const Color mintGreenDarkTheme = Color(0xFF34D399);
  static const Color skyBlueDarkTheme = Color(0xFF60A5FA);
  static const Color sproutYellowDarkTheme = Color(0xFFFBBF24);
  static const Color cherryRedDarkTheme = Color(0xFFEF4444);

  /// 获取暗色主题下的主题色
  static Color getPrimaryColor(bool isDark) =>
      isDark ? mintGreenDarkTheme : mintGreen;
  static Color getSecondaryColor(bool isDark) =>
      isDark ? skyBlueDarkTheme : skyBlue;
  static Color getAccentColor(bool isDark) =>
      isDark ? sproutYellowDarkTheme : sproutYellow;
  static Color getErrorColor(bool isDark) =>
      isDark ? cherryRedDarkTheme : cherryRed;

  /// 获取薄荷绿（适配暗色主题）
  static Color getMintColor(bool isDark) =>
      isDark ? mintGreenDarkTheme : mintGreen;

  /// 获取快捷操作颜色
  static Color getActionColor(String label) {
    final colorMap = {
      '打卡签到': actionCheckIn,
      '实时监控': actionMonitor,
      '集群对讲': actionIntercom,
      '轨迹回放': actionTrack,
      '电子围栏': actionFence,
      '告警记录': actionAlarm,
    };
    return colorMap[label] ?? const Color(0xFF6B7280);
  }
}
