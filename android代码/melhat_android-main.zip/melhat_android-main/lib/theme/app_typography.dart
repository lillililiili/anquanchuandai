import 'package:flutter/material.dart';

/// 字体样式定义
class AppTypography {
  AppTypography._();

  /// 默认字体家族
  static const String fontFamily = 'Roboto';

  /// 大标题（首页用户名等）
  static const TextStyle headlineLarge = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    letterSpacing: -0.5,
  );

  /// 页面标题（AppBar）
  static const TextStyle headlineMedium = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    letterSpacing: -0.3,
  );

  /// 卡片标题
  static const TextStyle title = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
  );

  /// 列表项标题
  static const TextStyle body = TextStyle(
    fontSize: 15,
    fontWeight: FontWeight.w600,
  );

  /// 副标题/辅助文字
  static const TextStyle subtitle = TextStyle(
    fontSize: 13,
    fontWeight: FontWeight.normal,
  );

  /// 小标签
  static const TextStyle caption = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w500,
  );

  /// 小按钮文字
  static const TextStyle button = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w600,
  );

  /// 获取 TextTheme
  static TextTheme get textTheme {
    return const TextTheme(
      headlineLarge: headlineLarge,
      headlineMedium: headlineMedium,
      titleLarge: title,
      bodyLarge: body,
      bodyMedium: subtitle,
      labelSmall: caption,
    );
  }
}
