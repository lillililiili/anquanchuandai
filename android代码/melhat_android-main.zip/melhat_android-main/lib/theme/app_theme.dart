import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_typography.dart';
import 'app_spacing.dart';

/// 应用主题配置
class AppTheme {
  AppTheme._();

  /// 明亮主题
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      progressIndicatorTheme: const ProgressIndicatorThemeData(year2023: false),
      brightness: Brightness.light,

      // 主色调
      primaryColor: SpringColors.mintGreen,
      colorScheme: const ColorScheme.light(
        primary: SpringColors.mintGreen,
        secondary: SpringColors.skyBlue,
        tertiary: SpringColors.sproutYellow,
        error: SpringColors.cherryRed,
        surface: SpringColors.cardBackgroundLight,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onTertiary: Colors.white,
        onError: Colors.white,
        onSurface: SpringColors.textPrimaryLight,
      ),

      // 背景色
      scaffoldBackgroundColor: SpringColors.backgroundLight,
      canvasColor: SpringColors.backgroundLight,

      // 卡片主题
      cardTheme: CardThemeData(
        color: SpringColors.cardBackgroundLight,
        elevation: 0,
        shadowColor: Colors.black.withValues(alpha: 0.05),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        ),
      ),

      // AppBar 主题
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: true,
        titleTextStyle: AppTypography.headlineMedium,
        iconTheme: IconThemeData(color: SpringColors.textPrimaryLight),
      ),

      // 文字主题
      textTheme: AppTypography.textTheme,

      // 图标主题
      iconTheme: const IconThemeData(
        color: SpringColors.textPrimaryLight,
        size: 24,
      ),

      // 分割线
      dividerTheme: const DividerThemeData(
        color: SpringColors.dividerLight,
        thickness: 1,
        space: 1,
      ),

      // 输入框主题
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFFF8F9FC),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.lg,
          vertical: AppSpacing.md,
        ),
      ),

      // 按钮主题
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: SpringColors.mintGreen,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.xl,
            vertical: AppSpacing.md,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          ),
        ),
      ),

      // Tab 主题
      tabBarTheme: const TabBarThemeData(
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: SpringColors.mintGreen,
        unselectedLabelColor: SpringColors.textTertiaryLight,
        labelStyle: AppTypography.title,
      ),
    );
  }

  /// 暗色主题
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      progressIndicatorTheme: const ProgressIndicatorThemeData(year2023: false),
      brightness: Brightness.dark,

      // 主色调（暗色主题下使用稍亮的版本）
      primaryColor: SpringColors.mintGreenDarkTheme,
      colorScheme: const ColorScheme.dark(
        primary: SpringColors.mintGreenDarkTheme,
        secondary: SpringColors.skyBlueDarkTheme,
        tertiary: SpringColors.sproutYellowDarkTheme,
        error: SpringColors.cherryRedDarkTheme,
        surface: SpringColors.surfaceDark,
        onPrimary: Colors.black,
        onSecondary: Colors.black,
        onTertiary: Colors.black,
        onError: Colors.black,
        onSurface: SpringColors.textPrimaryDark,
      ),

      // 背景色
      scaffoldBackgroundColor: SpringColors.backgroundDark,
      canvasColor: SpringColors.backgroundDark,

      // 卡片主题
      cardTheme: CardThemeData(
        color: SpringColors.cardBackgroundDark,
        elevation: 0,
        shadowColor: Colors.black.withValues(alpha: 0.3),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        ),
      ),

      // AppBar 主题
      appBarTheme: const AppBarTheme(
        backgroundColor: SpringColors.surfaceDark,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: true,
        titleTextStyle: AppTypography.headlineMedium,
        iconTheme: IconThemeData(color: SpringColors.textPrimaryDark),
      ),

      // 文字主题
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: SpringColors.textPrimaryDark,
        ),
        headlineMedium: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: SpringColors.textPrimaryDark,
        ),
        titleLarge: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: SpringColors.textPrimaryDark,
        ),
        bodyLarge: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: SpringColors.textPrimaryDark,
        ),
        bodyMedium: TextStyle(
          fontSize: 13,
          color: SpringColors.textSecondaryDark,
        ),
        labelSmall: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: SpringColors.textSecondaryDark,
        ),
      ),

      // 图标主题
      iconTheme: const IconThemeData(
        color: SpringColors.textPrimaryDark,
        size: 24,
      ),

      // 分割线
      dividerTheme: const DividerThemeData(
        color: SpringColors.dividerDark,
        thickness: 1,
        space: 1,
      ),

      // 输入框主题
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF2A2A2A),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.lg,
          vertical: AppSpacing.md,
        ),
      ),

      // 按钮主题
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: SpringColors.mintGreenDarkTheme,
          foregroundColor: Colors.black,
          elevation: 0,
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.xl,
            vertical: AppSpacing.md,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          ),
        ),
      ),

      // Tab 主题
      tabBarTheme: const TabBarThemeData(
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: SpringColors.mintGreenDarkTheme,
        unselectedLabelColor: SpringColors.textTertiaryDark,
        labelStyle: AppTypography.title,
      ),
    );
  }
}
