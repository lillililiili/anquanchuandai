import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:latlong2/latlong.dart';
import '../controllers/trajectory_player_controller.dart';
import '../models/trajectory_point.dart';
import '../theme/theme.dart';
import '../hooks/use_theme.dart';
import 'trajectory_map_view.dart';
import 'app_map.dart';

/// 轨迹播放器视图组件
///
/// 集成 TrajectoryPlayerController，负责轨迹地图的显示和播放状态同步
///
/// 使用示例:
/// ```dart
/// // 方式 1：内部创建控制器
/// TrajectoryPlayerView(
///   points: points,
///   height: 200,
/// )
///
/// // 方式 2：使用外部控制器（与全屏组件共享状态）
/// final controller = useMemoized(() => TrajectoryPlayerController());
/// TrajectoryPlayerView(
///   points: points,
///   controller: controller,
///   height: 200,
/// )
/// ```
class TrajectoryPlayerView extends HookWidget {
  /// 轨迹点数据
  final List<TrajectoryPoint> points;

  /// 播放控制器（可选，不传则内部创建）
  final TrajectoryPlayerController? controller;

  /// 组件高度
  final double? height;

  /// 地图初始缩放级别
  final double initialZoom;

  /// 是否显示已播放点位
  final bool showPastPoints;

  /// 是否显示完整路径
  final bool showFullPath;

  /// 是否显示当前点
  final bool showCurrentPoint;

  /// 是否允许地图交互
  final bool interactive;

  /// 当前点变化回调
  final ValueChanged<int>? onCurrentIndexChanged;

  const TrajectoryPlayerView({
    super.key,
    required this.points,
    this.controller,
    this.height,
    this.initialZoom = 15.0,
    this.showPastPoints = true,
    this.showFullPath = true,
    this.showCurrentPoint = true,
    this.interactive = true,
    this.onCurrentIndexChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();

    // 使用传入的 controller 或创建内部的
    final playerController = useMemoized(
      () => controller ?? TrajectoryPlayerController(),
    );

    // 初始化轨迹点数据
    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        playerController.setPoints(points);
      });
      return null;
    }, [points]);

    // 订阅控制器状态变化，并使用 useValueListenable 触发重建
    final _ = useListenable(playerController);
    final currentIndex = playerController.currentIndex;

    // 转换轨迹点为 LatLng
    final latLngPoints = useMemoized(() {
      return points.map((p) => LatLng(p.latitude, p.longitude)).toList();
    }, [points]);

    // 地图控制器
    final mapController = useMemoized(() => MapController());

    // 自动调整地图视图（初次加载）
    useEffect(() {
      if (latLngPoints.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          try {
            mapController.fitCamera(
              CameraFit.bounds(
                bounds: LatLngBounds.fromPoints(latLngPoints),
                padding: const EdgeInsets.all(50),
              ),
            );
          } catch (_) {}
        });
      }
      return null;
    }, [points.length]);

    // 当前点变化时平滑移动
    useEffect(() {
      if (currentIndex >= 0 && currentIndex < latLngPoints.length) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          try {
            mapController.move(latLngPoints[currentIndex], initialZoom);
          } catch (_) {}
        });
      }
      return null;
    }, [currentIndex]);

    if (points.isEmpty) {
      return _buildEmptyState(theme);
    }

    return SizedBox(
      height: height ?? 200,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
        child: AppMap(
          mapController: mapController,
          initialCenter: latLngPoints.isNotEmpty
              ? latLngPoints.first
              : const LatLng(37.2408718814842, 118.81377768291111),
          initialZoom: initialZoom,
          interactionFlags: interactive
              ? InteractiveFlag.pinchZoom | InteractiveFlag.drag
              : InteractiveFlag.none,
          children: [
            // 轨迹图层
            ...useTrajectoryLayers(
              points: points,
              currentIndex: currentIndex,
              showPastPoints: showPastPoints,
              showFullPath: showFullPath,
              showCurrentPoint: showCurrentPoint,
            ),
          ],
        ),
      ),
    );
  }

  /// 构建空状态
  Widget _buildEmptyState(ThemeColors theme) {
    return Container(
      height: height ?? 200,
      decoration: BoxDecoration(
        color: theme.isDark ? const Color(0xFF2A2A2A) : const Color(0xFFF0F0F0),
        borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
      ),
      child: const Center(
        child: Text(
          '暂无轨迹数据',
          style: TextStyle(fontSize: 14, color: Colors.grey),
        ),
      ),
    );
  }
}
