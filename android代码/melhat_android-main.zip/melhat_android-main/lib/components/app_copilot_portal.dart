import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:rolling_intelligence_headband/store/chat_store.dart';
import 'package:rolling_intelligence_headband/store/user_store.dart';
import '../store/ai_config_store.dart';
import '../theme/app_colors.dart';
import '../views/chat/chat_page.dart';

/// AI Copilot Portal 组件
/// 使用 Stack 实现 overlay，在 builder 中使用可访问 MaterialApp 提供的 context
class AppCopilotPortal extends HookWidget {
  /// 子组件（路由页面内容）
  final Widget child;

  /// 面板高度比例
  final double heightFactor;

  const AppCopilotPortal({super.key, required this.child, this.heightFactor = 0.7});

  @override
  Widget build(BuildContext context) {
    final isExpanded = useState(ChatStore.isChatPanelOpen.value);
    final isFullscreen = useState(false);

    // 监听 Store 变化（AI 关闭面板时同步到本地）
    useEffect(() {
      final unsub = ChatStore.isChatPanelOpen.subscribe((open) {
        isExpanded.value = open;
        if (!open) isFullscreen.value = false;
      });
      return unsub;
    }, []);
    final animationController = useAnimationController(
      duration: const Duration(milliseconds: 300),
    );

    // 按钮位置状态
    final buttonLeft = useState(16.0);
    final buttonBottom = useState(90.0);
    final isDragging = useState(false);
    final dragStartPosition = useRef(Offset.zero);
    final initialButtonPosition = useRef(Offset.zero);

    // 滑动动画
    final slideAnimation = useMemoized(() {
      return Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero).animate(
        CurvedAnimation(
          parent: animationController,
          curve: Curves.easeOutCubic,
        ),
      );
    }, [animationController]);

    // 切换展开状态
    void toggleExpanded() {
      isExpanded.value = !isExpanded.value;
      ChatStore.instance.setChatPanelOpen(isExpanded.value);
      if (isExpanded.value) {
        animationController.forward();
      } else {
        animationController.reverse();
        FocusScope.of(context).unfocus();
      }
    }

    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // 使用 MediaQuery.viewInsets.bottom 替代自定义 hook
    final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;

    // 按钮尺寸
    const buttonSize = 56.0;
    const buttonMargin = 16.0;

    // 边界约束
    double clampLeft(double left) {
      return left.clamp(buttonMargin, screenWidth - buttonSize - buttonMargin);
    }

    double clampBottom(double bottom) {
      return bottom.clamp(
        buttonMargin,
        screenHeight - buttonSize - buttonMargin - 80,
      );
    }

    final isLoggedIn = useIsLoggedIn();

    // 检查 AI 配置是否完整
    final configStore = AIConfigStore.instance;
    final isConfigIncomplete = configStore.apiKey.isEmpty ||
        configStore.baseUrl.isEmpty ||
        configStore.model.isEmpty;

    // 在 builder 中使用，可以访问 MaterialApp 提供的 Directionality/Localizations/Overlay context
    return Stack(
      children: [
        // 页面内容
        child,

        // 半屏/全屏毛玻璃聊天面板
        if (isExpanded.value && isLoggedIn)
          Positioned(
            left: 0,
            right: 0,
            top: isFullscreen.value ? 0 : null,
            bottom: keyboardHeight,
            height: isFullscreen.value ? null : screenHeight * heightFactor,
            child: SlideTransition(
              position: slideAnimation,
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(
                  top: isFullscreen.value ? Radius.zero : const Radius.circular(24),
                ),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                  child: Material(
                    type: MaterialType.transparency,
                    child: Overlay(
                      initialEntries: [
                        OverlayEntry(
                          builder: (context) => Container(
                            decoration: BoxDecoration(
                              color: isDark
                                  ? Colors.black.withValues(alpha: 0.2)
                                  : Colors.white.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.vertical(
                                top: isFullscreen.value ? Radius.zero : const Radius.circular(24),
                              ),
                              border: Border(
                                top: BorderSide(
                                  color: isDark
                                      ? Colors.white.withValues(alpha: 0.1)
                                      : Colors.white.withValues(alpha: 0.5),
                                  width: 1,
                                ),
                              ),
                            ),
                            child: SafeArea(
                              top: isFullscreen.value,
                              bottom: true,
                              child: Column(
                                children: [
                                  _buildDragHandle(isDark),
                                  _buildHeader(context, isFullscreen),
                                  Divider(
                                    height: 1,
                                    color: isDark
                                        ? SpringColors.dividerDark
                                        : SpringColors.dividerLight,
                                  ),
                                  // AI 配置未完成提示
                                  if (isConfigIncomplete)
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.of(context).pushNamed('/ai-config');
                                      },
                                      child: Container(
                                        width: double.infinity,
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 16,
                                          vertical: 10,
                                        ),
                                        color: Colors.orange.withValues(alpha: 0.15),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              Icons.warning_amber_rounded,
                                              size: 18,
                                              color: Colors.orange,
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Text(
                                                'AI 服务未配置，请先设置 API Key 等参数',
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  color: isDark
                                                      ? Colors.orange.shade200
                                                      : Colors.orange.shade800,
                                                ),
                                              ),
                                            ),
                                            Icon(
                                              Icons.chevron_right,
                                              size: 18,
                                              color: isDark
                                                  ? Colors.orange.shade200
                                                  : Colors.orange.shade800,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  Expanded(
                                    child: ChatPage(
                                      showAppBar: false,
                                      enabled: !isConfigIncomplete,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

        // 入口按钮（可拖动）
        if (isLoggedIn)
          AnimatedPositioned(
            duration: isDragging.value
                ? Duration.zero
                : const Duration(milliseconds: 200),
            left: buttonLeft.value,
            bottom: buttonBottom.value + keyboardHeight,
            child: GestureDetector(
              onPanStart: (details) {
                isDragging.value = true;
                dragStartPosition.value = details.globalPosition;
                initialButtonPosition.value = Offset(
                  buttonLeft.value,
                  buttonBottom.value,
                );
              },
              onPanUpdate: (details) {
                final delta =
                    details.globalPosition - dragStartPosition.value;
                buttonLeft.value = clampLeft(
                  initialButtonPosition.value.dx + delta.dx,
                );
                buttonBottom.value = clampBottom(
                  initialButtonPosition.value.dy - delta.dy,
                );
              },
              onPanEnd: (details) {
                isDragging.value = false;
                final centerX = screenWidth / 2;
                if (buttonLeft.value + buttonSize / 2 < centerX) {
                  buttonLeft.value = buttonMargin;
                } else {
                  buttonLeft.value = screenWidth - buttonSize - buttonMargin;
                }
              },
              onTap: isDragging.value ? null : toggleExpanded,
              child: FloatingActionButton(
                onPressed: null,
                backgroundColor: isExpanded.value
                    ? Theme.of(context).colorScheme.surface
                    : SpringColors.mintGreen,
                foregroundColor: isExpanded.value
                    ? SpringColors.mintGreen
                    : Colors.white,
                elevation: isExpanded.value ? 2 : 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: Icon(
                    isExpanded.value
                        ? Icons.close
                        : Icons.smart_toy_outlined,
                    key: ValueKey(isExpanded.value),
                    size: 26,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  /// 构建拖拽指示条
  Widget _buildDragHandle(bool isDark) {
    return Container(
      margin: const EdgeInsets.only(top: 12, bottom: 8),
      width: 40,
      height: 4,
      decoration: BoxDecoration(
        color: isDark
            ? Colors.white.withValues(alpha: 0.3)
            : Colors.black.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }

  /// 构建标题栏
  Widget _buildHeader(BuildContext context, ValueNotifier<bool> isFullscreen) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: SpringColors.mintGreen.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.smart_toy_outlined,
              size: 20,
              color: SpringColors.mintGreen,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'AI 助手',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
          const Spacer(),
          IconButton(
            icon: Icon(
              isFullscreen.value ? Icons.fullscreen_exit : Icons.fullscreen,
              size: 20,
            ),
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.5),
            tooltip: isFullscreen.value ? '退出全屏' : '全屏',
            onPressed: () {
              isFullscreen.value = !isFullscreen.value;
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, size: 20),
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.5),
            tooltip: '清空聊天记录',
            onPressed: () {
              ChatStore.instance.clearMessages();
            },
          ),
        ],
      ),
    );
  }
}