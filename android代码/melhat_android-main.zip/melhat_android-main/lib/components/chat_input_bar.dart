import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:voice_recognizer/voice_recognizer.dart';
import 'package:rolling_intelligence_headband/models/chat_models.dart';

/// 聊天输入框组件
///
/// 布局：上方多行输入框，下方语音按钮 + 发送按钮
class ChatInputBar extends HookWidget {
  final TextEditingController controller;
  final Future<void> Function({String? content, ChatMessage? message}) onSend;
  final VoidCallback? onStop;
  final bool isSending;
  final bool enabled;

  const ChatInputBar({
    super.key,
    required this.controller,
    required this.onSend,
    this.onStop,
    this.isSending = false,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    final text = useState('');

    // 监听文本变化
    useEffect(() {
      void listener() => text.value = controller.text;
      controller.addListener(listener);
      return () => controller.removeListener(listener);
    }, []);

    // 语音识别结果回调
    void onVoiceResult(String result) {
      if (result.isNotEmpty) {
        final currentText = controller.text;
        final newText = currentText.isEmpty ? result : '$currentText$result';
        controller.text = newText;
        controller.selection = TextSelection.fromPosition(
          TextPosition(offset: newText.length),
        );
      }
    }

    return Container(
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: 12,
        bottom: 12,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 上方：输入框 + 发送按钮
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              // 多行输入框
              Expanded(
                child: Container(
                  constraints: const BoxConstraints(minHeight: 36, maxHeight: 120),
                  padding: const EdgeInsets.only(left: 14, top: 8, bottom: 8, right: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5F6FA),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFE5E7EB)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: TextField(
                          controller: controller,
                          enabled: enabled,
                          decoration: InputDecoration(
                            hintText: enabled ? '输入消息...' : '请先配置 AI 服务',
                            hintStyle: const TextStyle(
                              color: Color(0xFF9CA3AF),
                              fontSize: 13,
                            ),
                            border: InputBorder.none,
                            isDense: true,
                            contentPadding: EdgeInsets.zero,
                          ),
                          maxLines: 4,
                          minLines: 1,
                          style: const TextStyle(
                            fontSize: 13,
                            color: Color(0xFF1F2937),
                          ),
                          onSubmitted:
                              (isSending || !enabled) ? null : (value) => onSend(content: value),
                        ),
                      ),
                      // 清空按钮
                      if (text.value.isNotEmpty)
                        GestureDetector(
                          onTap: () {
                            controller.clear();
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(left: 4, bottom: 2),
                            child: Icon(
                              Icons.close_rounded,
                              size: 18,
                              color: const Color(0xFF9CA3AF),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // 发送按钮
              GestureDetector(
                onTap: isSending
                    ? onStop
                    : enabled
                        ? () => onSend(content: controller.text)
                        : null,
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: isSending
                        ? const Color(0xFFDC2626)
                        : enabled
                            ? const Color(0xFF10B981)
                            : const Color(0xFF9CA3AF),
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: (isSending
                                ? const Color(0xFFDC2626)
                                : const Color(0xFF10B981))
                            .withValues(alpha: 0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: isSending
                      ? const Icon(Icons.stop_rounded,
                          size: 20, color: Colors.white)
                      : const Icon(Icons.send_rounded,
                          size: 18, color: Colors.white),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // 下方：语音按钮
          Center(
            child: VoiceRecordButton(
              onResult: onVoiceResult,
              themeColor: const Color(0xFF10B981),
              size: 44,
              maxDuration: 30,
              showDuration: true,
              showRipple: true,
            ),
          ),
        ],
      ),
    );
  }
}
