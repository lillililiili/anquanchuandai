import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import '../controllers/trajectory_player_controller.dart';
import '../models/playback_speed.dart';
import '../theme/theme.dart';
import '../hooks/use_theme.dart';

/// 轨迹播放控制面板组件
///
/// 提供以下控制功能：
/// - 进度条（支持拖拽）
/// - 播放/暂停按钮
/// - 快进/快退按钮
/// - 速度选择按钮
/// - 时间显示（开始时间、当前时间、结束时间）
///
/// [isFullScreen] 是否为全屏模式，为true时：
/// - 布局变为两行（进度条和控制按钮在一行）
/// - 背景变为半透明
/// - 全屏按钮文字变为"退出全屏"
class TrajectoryPlayerControls extends HookWidget {
  /// 播放控制器
  final TrajectoryPlayerController controller;

  /// 是否显示速度按钮
  final bool showSpeedButton;

  /// 是否显示时间标签
  final bool showTimeLabels;

  /// 全屏按钮回调
  final VoidCallback? onFullScreen;

  /// 是否为全屏模式
  final bool isFullScreen;

  const TrajectoryPlayerControls({
    super.key,
    required this.controller,
    this.showSpeedButton = true,
    this.showTimeLabels = true,
    this.onFullScreen,
    this.isFullScreen = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();

    // 监听控制器状态变化
    final isPlaying = useValueNotifier(controller.isPlaying);
    final currentIndex = useValueNotifier(controller.currentIndex);
    final speed = useValueNotifier(controller.speed);

    // 订阅控制器状态
    useEffect(() {
      void listener() {
        isPlaying.value = controller.isPlaying;
        currentIndex.value = controller.currentIndex;
        speed.value = controller.speed;
      }

      controller.addListener(listener);
      return () => controller.removeListener(listener);
    }, []);

    // 开始时间和结束时间
    final startTime = controller.startTimestamp ?? '00:00';
    final endTime = controller.endTimestamp ?? '00:00';
    final currentTimestamp = currentIndex.value >= 0 &&
            currentIndex.value < controller.points.length
        ? controller.points[currentIndex.value].timestamp
        : '00:00';

    // 格式化显示时间
    final currentTimeDisplay = _formatTimeOnly(currentTimestamp); // 只显示时分秒
    final startTimeParts = _splitDateTime(startTime); // 分为日期和时间两行
    final endTimeParts = _splitDateTime(endTime);

    return Container(
      decoration: BoxDecoration(
        color: isFullScreen
            ? theme.cardBackground.withValues(alpha: 0.85)
            : theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        boxShadow: AppShadows.card,
      ),
      child: isFullScreen ? _buildFullScreenLayout(
        theme: theme,
        isPlaying: isPlaying,
        currentIndex: currentIndex,
        speed: speed,
        startTimeParts: startTimeParts,
        endTimeParts: endTimeParts,
        currentTimeDisplay: currentTimeDisplay,
      ) : _buildNormalLayout(
        theme: theme,
        isPlaying: isPlaying,
        currentIndex: currentIndex,
        speed: speed,
        startTimeParts: startTimeParts,
        endTimeParts: endTimeParts,
        currentTimeDisplay: currentTimeDisplay,
      ),
    );
  }

  /// 全屏模式布局（两行）
  Widget _buildFullScreenLayout({
    required ThemeColors theme,
    required ValueNotifier<bool> isPlaying,
    required ValueNotifier<int> currentIndex,
    required ValueNotifier<PlaybackSpeed> speed,
    required ({String date, String time}) startTimeParts,
    required ({String date, String time}) endTimeParts,
    required String currentTimeDisplay,
  }) {
    // 监听 currentIndex 变化以更新进度条
    final currentIndexValue = useValueListenable(currentIndex);

    return Padding(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 第一行：进度条 + 当前时间 + 控制按钮
          Row(
            children: [
              // 开始时间
              if (showTimeLabels)
                SizedBox(
                  width: 50,
                  child: Text(
                    startTimeParts.time.isNotEmpty ? startTimeParts.time : '00:00',
                    style: TextStyle(
                      fontSize: 12,
                      color: theme.textTertiary,
                    ),
                    textAlign: TextAlign.center,
                  ),
                )
              else
                const SizedBox(width: AppSpacing.sm),
              // 进度条
              Expanded(
                child: SliderTheme(
                  data: SliderThemeData(
                    activeTrackColor: SpringColors.skyBlue,
                    inactiveTrackColor: theme.isDark
                        ? const Color(0xFF3A3A3A)
                        : const Color(0xFFE5E5E5),
                    thumbColor: SpringColors.skyBlue,
                    trackHeight: 4.0,
                    thumbShape: const RoundSliderThumbShape(
                      enabledThumbRadius: 6.0,
                    ),
                  ),
                  child: Slider(
                    value: currentIndexValue < 0
                        ? 0
                        : currentIndexValue.toDouble(),
                    min: 0,
                    max: controller.totalCount > 0
                        ? (controller.totalCount - 1).toDouble()
                        : 100,
                    onChanged: controller.totalCount > 0
                        ? (value) {
                            controller.seekTo(value.toInt());
                          }
                        : null,
                  ),
                ),
              ),
              // 结束时间
              if (showTimeLabels)
                SizedBox(
                  width: 50,
                  child: Text(
                    endTimeParts.time.isNotEmpty ? endTimeParts.time : '00:00',
                    style: TextStyle(
                      fontSize: 12,
                      color: theme.textTertiary,
                    ),
                    textAlign: TextAlign.center,
                  ),
                )
              else
                const SizedBox(width: AppSpacing.sm),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          // 第二行：控制按钮 + 时间显示
          Row(
            children: [
              // 左侧：速度选择
              if (showSpeedButton)
                _buildSpeedButton(
                  speed: speed.value,
                  onTap: () => controller.toggleSpeed(),
                )
              else
                const SizedBox(width: 60),
              // 中间：播放控制按钮
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildControlButton(
                      icon: Icons.fast_rewind,
                      theme: theme,
                      onTap: () => controller.stepBackward(),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    _buildPlayButton(
                      theme: theme,
                      isPlaying: isPlaying,
                      onTap: () => controller.togglePlay(),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    _buildControlButton(
                      icon: Icons.fast_forward,
                      theme: theme,
                      onTap: () => controller.stepForward(),
                    ),
                  ],
                ),
              ),
              // 右侧：退出全屏按钮 + 当前时间
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // 当前时间
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSpacing.md,
                      vertical: AppSpacing.sm,
                    ),
                    decoration: BoxDecoration(
                      color: SpringColors.skyBlue.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(AppSpacing.radiusSmall),
                    ),
                    child: Text(
                      currentTimeDisplay,
                      style: TextStyle(
                        fontSize: 13,
                        color: theme.textPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  // 退出全屏按钮
                  if (onFullScreen != null)
                    _buildExitFullScreenButton(onTap: onFullScreen!),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// 普通模式布局（三行）
  Widget _buildNormalLayout({
    required ThemeColors theme,
    required ValueNotifier<bool> isPlaying,
    required ValueNotifier<int> currentIndex,
    required ValueNotifier<PlaybackSpeed> speed,
    required ({String date, String time}) startTimeParts,
    required ({String date, String time}) endTimeParts,
    required String currentTimeDisplay,
  }) {
    // 监听 currentIndex 变化以更新进度条
    final currentIndexValue = useValueListenable(currentIndex);

    return Column(
      children: [
        // 标题栏
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xl,
            AppSpacing.xl,
            AppSpacing.xl,
            AppSpacing.lg,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '轨迹回放控制',
                style: AppTypography.title.copyWith(
                  color: theme.textPrimary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Row(
                children: [
                  // 速度选择
                  if (showSpeedButton)
                    _buildSpeedButton(
                      speed: speed.value,
                      onTap: () => controller.toggleSpeed(),
                    ),
                  // 全屏按钮
                  if (onFullScreen != null)
                    _buildFullScreenButton(onTap: onFullScreen!),
                ],
              ),
            ],
          ),
        ),
        // 进度条和控制按钮
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
          child: Column(
            children: [
              // 进度条和当前时间
              Row(
                children: [
                  // 进度条
                  Expanded(
                    child: SliderTheme(
                      data: SliderThemeData(
                        activeTrackColor: SpringColors.skyBlue,
                        inactiveTrackColor: theme.isDark
                            ? const Color(0xFF3A3A3A)
                            : const Color(0xFFE5E5E5),
                        thumbColor: SpringColors.skyBlue,
                        trackHeight: 4.0,
                        thumbShape: const RoundSliderThumbShape(
                          enabledThumbRadius: 6.0,
                        ),
                      ),
                      child: Slider(
                        value: currentIndexValue < 0
                            ? 0
                            : currentIndexValue.toDouble(),
                        min: 0,
                        max: controller.totalCount > 0
                            ? (controller.totalCount - 1).toDouble()
                            : 100,
                        onChanged: controller.totalCount > 0
                            ? (value) {
                                controller.seekTo(value.toInt());
                              }
                            : null,
                      ),
                    ),
                  ),
                  // 当前播放时间
                  SizedBox(
                    width: 60,
                    child: Text(
                      currentTimeDisplay,
                      style: TextStyle(
                        fontSize: 13,
                        color: theme.textPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                      textAlign: TextAlign.right,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.sm),
              // 时间标签和控制按钮
              Row(
                children: [
                  // 左侧：开始时间（两行显示：月日 + 时分）
                  if (showTimeLabels)
                    SizedBox(
                      width: 60,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            startTimeParts.date,
                            style: TextStyle(
                              fontSize: 12,
                              color: theme.textTertiary,
                            ),
                          ),
                          Text(
                            startTimeParts.time,
                            style: TextStyle(
                              fontSize: 12,
                              color: theme.textTertiary,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    const SizedBox(width: AppSpacing.lg),
                  // 中间：播放控制按钮（居中）
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // 快退按钮
                        _buildControlButton(
                          icon: Icons.fast_rewind,
                          theme: theme,
                          onTap: () => controller.stepBackward(),
                        ),
                        const SizedBox(width: AppSpacing.md),
                        // 播放/暂停按钮
                        _buildPlayButton(
                          theme: theme,
                          isPlaying: isPlaying,
                          onTap: () => controller.togglePlay(),
                        ),
                        const SizedBox(width: AppSpacing.md),
                        // 快进按钮
                        _buildControlButton(
                          icon: Icons.fast_forward,
                          theme: theme,
                          onTap: () => controller.stepForward(),
                        ),
                      ],
                    ),
                  ),
                  // 右侧：结束时间（两行显示：月日 + 时分）
                  if (showTimeLabels)
                    SizedBox(
                      width: 60,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            endTimeParts.date,
                            style: TextStyle(
                              fontSize: 12,
                              color: theme.textTertiary,
                            ),
                          ),
                          Text(
                            endTimeParts.time,
                            style: TextStyle(
                              fontSize: 12,
                              color: theme.textTertiary,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    const SizedBox(width: AppSpacing.lg),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: AppSpacing.lg),
      ],
    );
  }

  Widget _buildSpeedButton({
    required PlaybackSpeed speed,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.sm,
        ),
        decoration: BoxDecoration(
          color: SpringColors.skyBlue.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(AppSpacing.radiusSmall),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.speed, size: 16, color: SpringColors.skyBlue),
            const SizedBox(width: AppSpacing.xs),
            Text(
              '${speed.label}x',
              style: const TextStyle(
                fontSize: 13,
                color: SpringColors.skyBlue,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFullScreenButton({VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.sm,
        ),
        margin: const EdgeInsets.only(left: AppSpacing.sm),
        decoration: BoxDecoration(
          color: SpringColors.skyBlue.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(AppSpacing.radiusSmall),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.fullscreen, size: 16, color: SpringColors.skyBlue),
            const SizedBox(width: AppSpacing.xs),
            const Text(
              '全屏',
              style: TextStyle(
                fontSize: 13,
                color: SpringColors.skyBlue,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExitFullScreenButton({VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.sm,
        ),
        decoration: BoxDecoration(
          color: SpringColors.cherryRed.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(AppSpacing.radiusSmall),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.fullscreen_exit, size: 16, color: SpringColors.cherryRed),
            const SizedBox(width: AppSpacing.xs),
            const Text(
              '退出全屏',
              style: TextStyle(
                fontSize: 13,
                color: SpringColors.cherryRed,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required ThemeColors theme,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: theme.isDark
              ? const Color(0xFF3A3A3A)
              : const Color(0xFFE5E5E5),
          borderRadius: BorderRadius.circular(AppSpacing.radiusSmall),
        ),
        child: Icon(icon, size: 18, color: theme.textPrimary),
      ),
    );
  }

  Widget _buildPlayButton({
    required ThemeColors theme,
    required ValueNotifier<bool> isPlaying,
    VoidCallback? onTap,
  }) {
    final isPlayingValue = useValueListenable(isPlaying);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: const BoxDecoration(
          color: Colors.black,
          shape: BoxShape.circle,
        ),
        child: Icon(
          isPlayingValue ? Icons.pause : Icons.play_arrow,
          size: 20,
          color: Colors.white,
        ),
      ),
    );
  }

  /// 只提取时间部分（HH:mm:ss）
  /// 输入格式: "YYYY-MM-DD HH:mm:ss" 或 "YYYY-MM-DD HH:mm"
  /// 输出格式: "HH:mm:ss" 或 "HH:mm"
  String _formatTimeOnly(String timestamp) {
    if (timestamp.length < 5) return timestamp;
    // 按空格分割，取时间部分
    final parts = timestamp.split(' ');
    if (parts.length >= 2) {
      return parts[1]; // 返回 HH:mm:ss 或 HH:mm
    }
    return timestamp;
  }

  /// 将日期时间分为日期和时间两行
  /// 输入格式: "YYYY-MM-DD HH:mm:ss" 或 "YYYY-MM-DD HH:mm"
  /// 返回: {date: "MM-DD", time: "HH:mm"}
  ({String date, String time}) _splitDateTime(String timestamp) {
    if (timestamp.length < 5) {
      return (date: timestamp, time: '');
    }
    final parts = timestamp.split(' ');
    if (parts.length >= 2) {
      final dateParts = parts[0].split('-');
      if (dateParts.length >= 3) {
        // 返回 MM-DD 和 HH:mm
        final monthDay = '${dateParts[1]}-${dateParts[2]}';
        final time = parts[1].length > 5 ? parts[1].substring(0, 5) : parts[1];
        return (date: monthDay, time: time);
      }
    }
    return (date: timestamp, time: '');
  }
}
