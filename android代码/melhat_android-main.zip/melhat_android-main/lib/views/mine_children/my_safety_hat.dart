import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import '../../api/hat.dart';
import '../../hooks/use_theme.dart';
import '../../models/hat.dart';
import '../../store/user_store.dart';
import '../../theme/theme.dart';
import '../../theme/theme_signal.dart';
import '../../utils/app_logger.dart';

/// 我的安全帽页面
class MySafetyHatPage extends HookWidget {
  const MySafetyHatPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();
    final hatData = useState<Hat?>(null);
    final isLoading = useState(true);

    // 获取当前用户绑定的安全帽
    final hatContext = useContext();
    useEffect(() {
      Future<void> fetchHat() async {
        try {
          final userId = UserStore.instance.userInfo?.userId;
          if (userId != null) {
            final hat = await HatApi.getHatByUserId(userId.toString());
            if (!hatContext.mounted) return;
            hatData.value = hat;
          }
        } catch (e) {
          AppLogger.e('my_safety_hat fetchHat error', e);
        } finally {
          if (hatContext.mounted) {
            isLoading.value = false;
          }
        }
      }

      fetchHat();
      return null;
    }, []);

    return Scaffold(
      backgroundColor: theme.background,
      appBar: _buildAppBar(context, theme),
      body: isLoading.value
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Column(
                children: [
                  const SizedBox(height: AppSpacing.lg),
                  // 1. 已绑定安全帽卡片
                  _BoundSafetyHatCard(theme: theme, hat: hatData.value),
                  const SizedBox(height: AppSpacing.lg),
                  // 2. 设备状态卡片
                  _DeviceStatusCard(theme: theme, hat: hatData.value),
                  const SizedBox(height: AppSpacing.lg),
                  // 3. 设备信息卡片
                  _DeviceInfoCard(theme: theme, hat: hatData.value),
                  const SizedBox(height: AppSpacing.lg),
                  // 4. 绑定人员信息卡片
                  _BoundPersonCard(theme: theme, hat: hatData.value),
                  const SizedBox(height: AppSpacing.lg),
                  // 5. 绑定历史记录卡片
                  _BindingHistoryCard(theme: theme, hat: hatData.value),
                  const SizedBox(height: AppSpacing.xl),
                ],
              ),
            ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context, ThemeColors theme) {
    return AppBar(
      backgroundColor: theme.background,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      leading: GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Container(
          margin: const EdgeInsets.all(AppSpacing.sm),
          decoration: BoxDecoration(
            color: SpringColors.mintGreen.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          ),
          child: const Icon(
            Icons.arrow_back_ios_new,
            size: 18,
            color: SpringColors.mintGreen,
          ),
        ),
      ),
      title: Text(
        '我的安全帽',
        style: AppTypography.headlineMedium.copyWith(color: theme.textPrimary),
      ),
      centerTitle: true,
    );
  }
}

// ==================== 已绑定安全帽卡片 ====================
class _BoundSafetyHatCard extends StatelessWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _BoundSafetyHatCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // 安全帽图标
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: SpringColors.mintGreen.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.construction,
              color: SpringColors.mintGreen,
              size: 40,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // 标题
          Text(
            '已绑定安全帽',
            textAlign: TextAlign.center,
            style: AppTypography.title.copyWith(
              color: theme.textPrimary,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          // 描述文字
          Text(
            hat != null
                ? '安全帽设备 ${hat?.hatNumber ?? "未知"} 已与您的账号绑定'
                : '暂无绑定的安全帽设备',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: theme.textSecondary),
          ),
        ],
      ),
    );
  }
}

// ==================== 设备状态卡片 ====================
class _DeviceStatusCard extends StatelessWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _DeviceStatusCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: SpringColors.skyBlue.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Icon(
                  Icons.info_outline,
                  color: SpringColors.skyBlue,
                  size: 16,
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Text(
                '设备状态',
                style: AppTypography.title.copyWith(
                  color: theme.textPrimary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          // 状态网格
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            mainAxisSpacing: AppSpacing.lg,
            crossAxisSpacing: AppSpacing.lg,
            childAspectRatio: 1.5,
            children: [
              _StatusGridItem(
                value: hat?.electricityUsage != null
                    ? '${hat!.electricityUsage!.toInt()}%'
                    : '--',
                label: '剩余电量',
                valueColor: SpringColors.mintGreen,
                theme: theme,
              ),
              _StatusGridItem(
                value: hat?.storageUsage != null
                    ? '${hat!.storageUsage!.toInt()}%'
                    : '--',
                label: '存储空间',
                valueColor: SpringColors.skyBlue,
                theme: theme,
              ),
              _StatusGridItem(
                value: _getStatusText(hat?.status),
                label: '设备状态',
                valueColor: _getStatusColor(hat?.status),
                theme: theme,
              ),
              _StatusGridItem(
                value: '--',
                label: '已使用',
                valueColor: SpringColors.sproutYellow,
                theme: theme,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatusGridItem extends StatelessWidget {
  final String value;
  final String label;
  final Color valueColor;
  final ThemeColors theme;

  const _StatusGridItem({
    required this.value,
    required this.label,
    required this.valueColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: theme.isDark ? const Color(0xFF2A2A2A) : const Color(0xFFF8F9FA),
        borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            value,
            style: AppTypography.title.copyWith(
              color: valueColor,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            label,
            style: TextStyle(fontSize: 12, color: theme.textSecondary),
          ),
        ],
      ),
    );
  }
}

// ==================== 设备信息卡片 ====================
class _DeviceInfoCard extends StatelessWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _DeviceInfoCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: SpringColors.skyBlue.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Icon(
                  Icons.construction,
                  color: SpringColors.skyBlue,
                  size: 16,
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Text(
                '设备信息',
                style: AppTypography.title.copyWith(
                  color: theme.textPrimary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          // 信息列表
          _InfoRow(
            label: '设备编号',
            value: hat?.hatNumber ?? '未知',
            theme: theme,
            showDivider: true,
          ),
          _InfoRow(
            label: '绑定时间',
            value: hat?.bindTime ?? '--',
            theme: theme,
            showDivider: false,
          ),
        ],
      ),
    );
  }
}

// ==================== 绑定人员信息卡片 ====================
class _BoundPersonCard extends StatelessWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _BoundPersonCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: SpringColors.skyBlue.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Icon(
                  Icons.person,
                  color: SpringColors.skyBlue,
                  size: 16,
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Text(
                '绑定人员信息',
                style: AppTypography.title.copyWith(
                  color: theme.textPrimary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          // 人员信息列表
          _InfoRow(
            label: '姓名',
            value: hat?.bindUserName ?? '--',
            theme: theme,
            showDivider: true,
          ),
          _InfoRow(
            label: '组名',
            value: hat?.bindGroup ?? '--',
            theme: theme,
            showDivider: false,
          ),
        ],
      ),
    );
  }
}

// ==================== 信息行组件 ====================
class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final ThemeColors theme;
  final bool showDivider;

  const _InfoRow({
    required this.label,
    required this.value,
    required this.theme,
    required this.showDivider,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            SizedBox(
              width: 80,
              child: Text(
                label,
                style: TextStyle(fontSize: 14, color: theme.textSecondary),
              ),
            ),
            Expanded(
              child: Text(
                value,
                style: TextStyle(fontSize: 14, color: theme.textPrimary),
              ),
            ),
          ],
        ),
        if (showDivider) ...[
          const SizedBox(height: AppSpacing.lg),
          Divider(
            height: 1,
            color: theme.isDark
                ? const Color(0x1FFFFFFF)
                : const Color(0x14000000),
          ),
          const SizedBox(height: AppSpacing.lg),
        ],
      ],
    );
  }
}

// ==================== 绑定历史记录卡片 ====================
class _BindingHistoryCard extends StatelessWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _BindingHistoryCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题
          Text(
            '绑定历史记录',
            style: AppTypography.title.copyWith(
              color: theme.textPrimary,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // 历史记录列表
          if (hat != null && hat?.bindTime != null) ...[
            _HistoryItem(
              type: HistoryType.bind,
              time: hat!.bindTime!,
              description:
                  '安全帽 ${hat!.hatNumber ?? "未知"} 绑定到 ${hat!.bindUserName ?? "未知用户"}',
              theme: theme,
              showDivider: false,
            ),
          ] else ...[
            Center(
              child: Text(
                '暂无绑定历史记录',
                style: TextStyle(fontSize: 14, color: theme.textTertiary),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// 获取状态文本
String _getStatusText(String? status) {
  switch (status) {
    case 'online':
      return '在线';
    case 'offline':
      return '离线';
    default:
      return status ?? '未知';
  }
}

// 获取状态颜色
Color _getStatusColor(String? status) {
  switch (status) {
    case 'online':
      return SpringColors.mintGreen;
    case 'offline':
      return Colors.grey;
    default:
      return SpringColors.sproutYellow;
  }
}

enum HistoryType { bind, unbind }

class _HistoryItem extends StatelessWidget {
  final HistoryType type;
  final String time;
  final String description;
  final ThemeColors theme;
  final bool showDivider;

  const _HistoryItem({
    required this.type,
    required this.time,
    required this.description,
    required this.theme,
    required this.showDivider,
  });

  @override
  Widget build(BuildContext context) {
    final iconData = type == HistoryType.bind ? Icons.link : Icons.link_off;
    final iconColor = type == HistoryType.bind
        ? SpringColors.skyBlue.withValues(alpha: 0.1)
        : SpringColors.cherryRed.withValues(alpha: 0.1);
    final iconForegroundColor = type == HistoryType.bind
        ? SpringColors.skyBlue
        : SpringColors.cherryRed;

    return Column(
      children: [
        Row(
          children: [
            // 图标
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: iconColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(iconData, color: iconForegroundColor, size: 20),
            ),
            const SizedBox(width: AppSpacing.md),
            // 内容
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    type == HistoryType.bind ? '绑定设备' : '解绑设备',
                    style: AppTypography.body.copyWith(
                      color: theme.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    time,
                    style: TextStyle(fontSize: 12, color: theme.textTertiary),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    description,
                    style: TextStyle(fontSize: 12, color: theme.textSecondary),
                  ),
                ],
              ),
            ),
          ],
        ),
        if (showDivider) ...[
          const SizedBox(height: AppSpacing.lg),
          Divider(
            height: 1,
            color: theme.isDark
                ? const Color(0x1FFFFFFF)
                : const Color(0x14000000),
          ),
          const SizedBox(height: AppSpacing.lg),
        ],
      ],
    );
  }
}
