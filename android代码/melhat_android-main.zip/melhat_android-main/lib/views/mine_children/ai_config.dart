import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import '../../store/ai_config_store.dart';
import '../../service/ai_agent.dart';
import '../../hooks/use_theme.dart';
import '../../theme/theme.dart';
import '../../utils/app_logger.dart';

/// AI 配置页面
class AIConfigPage extends HookWidget {
  const AIConfigPage({super.key});

  @override
  Widget build(BuildContext context) {
    final configStore = useAIConfigStore();
    final theme = useTheme();

    // 表单控制器
    final apiKeyController = useTextEditingController(
      text: configStore.apiKey,
    );
    final baseUrlController = useTextEditingController(
      text: configStore.baseUrl,
    );
    final modelController = useTextEditingController(
      text: configStore.model,
    );

    // 密码可见性
    final isApiKeyVisible = useState(false);

    // 加载状态
    final isLoading = useState(false);

    // 监听配置变化，更新控制器
    useEffect(() {
      void updateControllers() {
        apiKeyController.text = configStore.apiKey;
        baseUrlController.text = configStore.baseUrl;
        modelController.text = configStore.model;
      }

      // 初始更新
      updateControllers();

      return null;
    }, []);

    // 保存配置
    Future<void> saveConfig() async {
      isLoading.value = true;
      try {
        await configStore.saveConfig(
          apiKey: apiKeyController.text.trim(),
          baseUrl: baseUrlController.text.trim(),
          model: modelController.text.trim(),
        );
        AIService.instance.reinit();

        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('配置已保存'),
              backgroundColor: Colors.green,
            ),
          );
        }
      } catch (e) {
        AppLogger.e('保存配置失败: $e');
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('保存失败: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } finally {
        isLoading.value = false;
      }
    }

    // 恢复默认配置
    Future<void> resetToDefault() async {
      final confirmed = await showDialog<bool>(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text('恢复默认配置'),
              content: const Text('确定要恢复默认配置吗？这将清除您自定义的 AI 配置。'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('取消'),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text('确定'),
                ),
              ],
            ),
      );

      if (confirmed == true) {
        isLoading.value = true;
        try {
          await configStore.resetToDefault();

          // 更新控制器
          apiKeyController.text = configStore.apiKey;
          baseUrlController.text = configStore.baseUrl;
          modelController.text = configStore.model;

          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('已恢复默认配置'),
                backgroundColor: Colors.green,
              ),
            );
          }
        } catch (e) {
          AppLogger.e('重置配置失败: $e');
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('重置失败: $e'),
                backgroundColor: Colors.red,
              ),
            );
          }
        } finally {
          isLoading.value = false;
        }
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI 配置'),
        actions: [
          TextButton(
            onPressed: resetToDefault,
            child: const Text('恢复默认'),
          ),
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 提示信息
                Container(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(
                    color: theme.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: theme.primary.withValues(alpha: 0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: theme.primary,
                        size: 20,
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      Expanded(
                        child: Text(
                          '配置 AI 服务的连接参数。修改后需要重新启动对话才能生效。',
                          style: AppTypography.caption.copyWith(
                            color: theme.textPrimary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.xl),

                // API Key
                _buildSectionTitle('API Key', theme),
                const SizedBox(height: AppSpacing.sm),
                _buildTextField(
                  controller: apiKeyController,
                  hintText: '输入 API Key',
                  obscureText: !isApiKeyVisible.value,
                  suffixIcon: IconButton(
                    icon: Icon(
                      isApiKeyVisible.value
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: theme.textSecondary,
                    ),
                    onPressed: () {
                      isApiKeyVisible.value = !isApiKeyVisible.value;
                    },
                  ),
                  theme: theme,
                ),
                const SizedBox(height: AppSpacing.lg),

                // Base URL
                _buildSectionTitle('Base URL', theme),
                const SizedBox(height: AppSpacing.sm),
                _buildTextField(
                  controller: baseUrlController,
                  hintText: '输入 API Base URL',
                  keyboardType: TextInputType.url,
                  theme: theme,
                ),
                const SizedBox(height: AppSpacing.lg),

                // Model
                _buildSectionTitle('Model', theme),
                const SizedBox(height: AppSpacing.sm),
                _buildTextField(
                  controller: modelController,
                  hintText: '输入模型名称',
                  theme: theme,
                ),
                const SizedBox(height: AppSpacing.xxl),

                // 保存按钮
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: isLoading.value ? null : saveConfig,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.primary,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                          AppSpacing.radiusMedium,
                        ),
                      ),
                    ),
                    child:
                        isLoading.value
                            ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  Colors.white,
                                ),
                              ),
                            )
                            : const Text(
                              '保存配置',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                  ),
                ),
              ],
            ),
          ),

          // 加载遮罩
          if (isLoading.value)
            Container(
              color: Colors.black.withValues(alpha: 0.3),
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, ThemeColors theme) {
    return Text(
      title,
      style: AppTypography.body.copyWith(
        fontWeight: FontWeight.bold,
        color: theme.textPrimary,
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    bool obscureText = false,
    TextInputType? keyboardType,
    Widget? suffixIcon,
    required ThemeColors theme,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      style: TextStyle(color: theme.textPrimary),
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(
          color: theme.textSecondary.withValues(alpha: 0.5),
        ),
        filled: true,
        fillColor: theme.cardBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          borderSide: BorderSide(color: theme.divider),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          borderSide: BorderSide(color: theme.divider),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          borderSide: BorderSide(color: theme.primary, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.md,
        ),
        suffixIcon: suffixIcon,
      ),
    );
  }

}
