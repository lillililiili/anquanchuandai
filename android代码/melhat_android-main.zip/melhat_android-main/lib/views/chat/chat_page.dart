import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import '../../hooks/use_chat.dart';
import '../../components/chat_message_bubble.dart';
import '../../components/chat_input_bar.dart';
import '../../components/agent_status_bar.dart';

/// AI 聊天页面
class ChatPage extends HookWidget {
  /// 是否显示 AppBar（false 时只返回 body，不包含 SafeArea）
  final bool showAppBar;

  /// 是否启用输入（false 时禁用发送）
  final bool enabled;

  const ChatPage({super.key, this.showAppBar = true, this.enabled = true});

  @override
  Widget build(BuildContext context) {
    final chat = useChat();

    Widget body = Column(
      children: [
        // Agent 状态栏
        AgentStatusBar(
          status: chat.status,
          step: chat.step,
          toolName: chat.currentTool,
        ),
        // 消息列表
        Expanded(
          child: chat.messages.isEmpty
              ? CustomScrollView(
                  slivers: [
                    SliverPadding(
                      padding: const EdgeInsets.only(top: 64),
                      sliver: SliverFillRemaining(
                        hasScrollBody: false,
                        child: _buildEmptyState(),
                      ),
                    ),
                  ],
                )
              : ListView.builder(
                  reverse: true,
                  controller: chat.scrollController,
                  padding: const EdgeInsets.all(16),
                  itemCount: chat.messages.length,
                  itemBuilder: (context, index) {
                    final message =
                        chat.messages[chat.messages.length - 1 - index];
                    return ChatMessageBubble(message: message);
                  },
                ),
        ),
        // 输入框
        ChatInputBar(
          controller: chat.textController,
          onSend: chat.sendMessage,
          onStop: chat.stopGeneration,
          isSending: chat.isTyping,
          enabled: enabled,
        ),
      ],
    );

    // 全屏模式：用 SafeArea 包裹
    if (showAppBar) {
      body = SafeArea(child: body);
    }

    // 只返回 body
    if (!showAppBar) {
      return Container(color: Colors.transparent, child: body);
    }

    // 返回完整页面
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'AI 助手',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Color(0xFF1F2937),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Color(0xFF6B7280)),
            onPressed: () => _showClearDialog(context, chat.clearMessages),
          ),
        ],
      ),
      body: body,
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: const Color(0x1410B981),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.smart_toy_outlined,
              size: 40,
              color: Color(0xFF10B981),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            '开始与 AI 对话',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Color(0xFF1F2937),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            '在下面输入你的问题，AI 助手会帮助你',
            style: TextStyle(fontSize: 14, color: Color(0xFF6B7280)),
          ),
        ],
      ),
    );
  }

  void _showClearDialog(BuildContext context, VoidCallback onClear) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('清空对话'),
        content: const Text('确定要清空所有对话记录吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              onClear();
              Navigator.pop(context);
            },
            child: const Text('确定', style: TextStyle(color: Color(0xFFDC2626))),
          ),
        ],
      ),
    );
  }
}
