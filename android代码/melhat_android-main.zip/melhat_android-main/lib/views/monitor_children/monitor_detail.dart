import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import '../../api/hat.dart';
import '../../api/intercom.dart';
import '../../components/app_map.dart';
import '../../components/skeleton_view.dart';
import '../../hooks/use_skeleton.dart';
import '../../hooks/use_theme.dart';
import '../../hooks/useAgoraRtcEngine.dart';
import '../../models/hat.dart';
import '../../models/hat_location_record.dart';
import '../../models/agora_credentials.dart';
import '../../theme/theme.dart';
import '../../utils/app_logger.dart';

/// 设备详情和位置数据组合
typedef DeviceDetailData = ({Hat? hat, HatLocationRecord? location});

/// 监控详情页面
class MonitorDetailPage extends HookWidget {
  final String? deviceId;
  final String? credentialsJson;
  final String? hatNumber;

  const MonitorDetailPage({
    super.key,
    this.deviceId,
    this.credentialsJson,
    this.hatNumber,
  });

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();

    // Agora RTC 状态
    final rtcState = useAgoraRtcEngine();
    final credentials = useState<AgoraCredentials?>(null);
    final isConnecting = useState(false);

    // 使用 skeleton hook 获取设备详情和位置
    final skeleton = useSkeleton<DeviceDetailData>(
      request: () async {
        if (deviceId == null) return (hat: null, location: null);

        // 并行获取设备详情和位置
        final results = await Future.wait([
          HatApi.getHatByNumber(hatNumber ?? ''),
          HatApi.getSingleHatHistory(hatId: deviceId!),
        ]);

        final hat = results[0] as Hat?;
        final records = results[1] as List<HatLocationRecord>;
        final location = records.isNotEmpty ? records.first : null;

        return (hat: hat, location: location);
      },
      isEmpty: (data) => data.hat == null,
    );

    // 连接 RTC（优先使用传入的 credentialsJson）
    useEffect(() {
      Future<void> connectToDevice() async {
        isConnecting.value = true;
        try {
          AgoraCredentials creds;

          // 如果传入了 credentialsJson，直接解析使用
          if (credentialsJson != null && credentialsJson!.isNotEmpty) {
            final jsonMap =
                jsonDecode(credentialsJson!) as Map<String, dynamic>;
            creds = AgoraCredentials.fromJson(jsonMap);
          } else {
            // 否则从 API 获取新凭证
            final hat = skeleton.data.value?.hat;
            if (hat?.hatNumber == null) return;

            creds = await IntercomApi.singleCall(
              hatNumber: hat!.hatNumber!,
              clientId: 'app_123',
              participant: hat.bindUserName,
            );
          }

          if (!context.mounted) return;
          credentials.value = creds;
          await rtcState.joinChannel(creds);
        } catch (e) {
          AppLogger.e('monitor_detail connectToDevice error', e);
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('设备连接失败: $e'),
                duration: const Duration(seconds: 3),
                backgroundColor: Colors.red,
              ),
            );
          }
        } finally {
          if (context.mounted) {
            isConnecting.value = false;
          }
        }
      }

      // 如果有 credentialsJson 立即连接，否则等待设备数据加载
      if (credentialsJson != null && credentialsJson!.isNotEmpty) {
        connectToDevice();
      } else if (skeleton.data.value?.hat?.hatNumber != null) {
        connectToDevice();
      }

      return () {
        unawaited(rtcState.leaveChannel());
      };
    }, [credentialsJson, skeleton.data.value?.hat?.hatNumber]);

    return Scaffold(
      backgroundColor: theme.background,
      appBar: _buildAppBar(context, theme),
      body: SkeletonView.fromHook(
        skeleton,
        (data) => SingleChildScrollView(
          child: Column(
            children: [
              // 视频播放区域
              _VideoPlayerSection(
                rtcState: rtcState,
                credentials: credentials.value,
                isConnecting: isConnecting.value,
                theme: theme,
              ),
              const SizedBox(height: AppSpacing.lg),
              // // 功能按钮区域
              // _ActionButtons(theme: theme),
              // const SizedBox(height: AppSpacing.lg),
              // 设备状态卡片
              _DeviceStatusCard(theme: theme, hat: data.hat),
              const SizedBox(height: AppSpacing.lg),
              // 设备信息卡片
              _DeviceInfoCard(theme: theme, hat: data.hat),
              const SizedBox(height: AppSpacing.lg),
              // 当前位置卡片
              _LocationCard(theme: theme, hat: data.hat),
              const SizedBox(height: AppSpacing.xl),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context, ThemeColors theme) {
    return AppBar(
      backgroundColor: theme.background,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      leading: GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Container(
          margin: const EdgeInsets.all(AppSpacing.sm),
          decoration: BoxDecoration(
            color: SpringColors.mintGreen.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          ),
          child: const Icon(
            Icons.arrow_back_ios_new,
            size: 18,
            color: SpringColors.mintGreen,
          ),
        ),
      ),
      title: Text(
        '监控详情',
        style: AppTypography.headlineMedium.copyWith(color: theme.textPrimary),
      ),
      centerTitle: true,
    );
  }
}

// ==================== 视频播放区域 ====================
class _VideoPlayerSection extends StatelessWidget {
  final AgoraRtcState rtcState;
  final AgoraCredentials? credentials;
  final bool isConnecting;
  final ThemeColors theme;
  final bool showControls = false;

  const _VideoPlayerSection({
    required this.rtcState,
    required this.credentials,
    required this.isConnecting,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    // 获取第一个远端用户
    final remoteUser = rtcState.remoteUsers.isNotEmpty
        ? rtcState.remoteUsers.values.first
        : null;

    return Container(
      width: double.infinity,
      height: 240,
      color: const Color(0xFF1A1A1A),
      child: Stack(
        children: [
          // 视频播放区域
          Positioned.fill(
            child: isConnecting
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const CircularProgressIndicator(color: Colors.white54),
                        const SizedBox(height: AppSpacing.md),
                        Text(
                          '正在连接设备...',
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  )
                : remoteUser != null && remoteUser.hasVideo
                ? AgoraVideoView(
                    controller: VideoViewController.remote(
                      rtcEngine: rtcState.engine!,
                      canvas: VideoCanvas(uid: remoteUser.uid),
                      connection: RtcConnection(
                        channelId: credentials?.channelName ?? '',
                      ),
                    ),
                  )
                : Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          remoteUser != null
                              ? Icons.videocam_off
                              : Icons.videocam_outlined,
                          size: 64,
                          color: Colors.white54,
                        ),
                        const SizedBox(height: AppSpacing.md),
                        Text(
                          remoteUser != null ? '等待视频流...' : '等待设备接入...',
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
          // 顶部时间戳
          Positioned(
            top: AppSpacing.md,
            left: AppSpacing.md,
            child: Text(
              _formatDateTime(),
              style: const TextStyle(fontSize: 14, color: Colors.white70),
            ),
          ),
          // 底部控制栏（隐藏）
          if (showControls)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(AppSpacing.lg),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // 全屏按钮
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.fullscreen,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                    // 播放/暂停按钮
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: SpringColors.mintGreen,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.pause,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                    ),
                    // 音量按钮
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.volume_up,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          // 实时标签
          Positioned(
            top: AppSpacing.md,
            right: AppSpacing.md,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: SpringColors.cherryRed,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.circle, size: 6, color: Colors.white),
                  SizedBox(width: 4),
                  Text(
                    'LIVE',
                    style: TextStyle(color: Colors.white, fontSize: 10),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDateTime() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')} ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
  }
}

// ==================== 功能按钮区域 ====================
class _ActionButtons extends HookWidget {
  final ThemeColors theme;

  const _ActionButtons({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
      child: Row(
        children: [
          // 发起单呼
          Expanded(
            child: _ActionButton(
              icon: Icons.call_outlined,
              label: '发起单呼',
              color: SpringColors.mintGreen,
              onTap: () {
                debugPrint('发起单呼');
              },
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          // 截图拍照
          Expanded(
            child: _ActionButton(
              icon: Icons.photo_camera_outlined,
              label: '截图拍照',
              color: SpringColors.skyBlue,
              onTap: () {
                debugPrint('截图拍照');
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends HookWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isPressed = useState(false);

    return GestureDetector(
      onTapDown: (_) => isPressed.value = true,
      onTapUp: (_) {
        isPressed.value = false;
        onTap();
      },
      onTapCancel: () => isPressed.value = false,
      child: AnimatedScale(
        scale: isPressed.value ? AppSpacing.pressScale : 1,
        duration: AppSpacing.pressDuration,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
            border: Border.all(color: color, width: 1),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: AppSpacing.md),
              Text(
                label,
                style: AppTypography.button.copyWith(
                  color: color,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== 设备状态卡片 ====================
class _DeviceStatusCard extends StatelessWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _DeviceStatusCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    final electricity = hat?.electricityUsage;
    final storage = hat?.storageUsage;

    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 卡片标题
          Text(
            '设备状态',
            style: AppTypography.title.copyWith(
              color: theme.textPrimary,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // 状态项列表
          Row(
            children: [
              // 电量
              Expanded(
                child: _StatusItem(
                  icon: Icons.battery_full,
                  label: '剩余电量',
                  value: electricity != null ? '${electricity.toInt()}%' : '--',
                  progressValue: electricity != null
                      ? electricity.toDouble() / 100
                      : 0,
                  progressColor: SpringColors.mintGreen,
                  theme: theme,
                ),
              ),
              const SizedBox(width: AppSpacing.xl),
              // 存储空间
              Expanded(
                child: _StatusItem(
                  icon: Icons.storage,
                  label: '存储空间',
                  value: storage != null ? '${storage.toInt()}%' : '--',
                  progressValue: storage != null ? storage.toDouble() / 100 : 0,
                  progressColor: SpringColors.skyBlue,
                  theme: theme,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatusItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final double progressValue;
  final Color progressColor;
  final ThemeColors theme;

  const _StatusItem({
    required this.icon,
    required this.label,
    required this.value,
    required this.progressValue,
    required this.progressColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: progressColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Icon(icon, color: progressColor, size: 18),
            ),
            const SizedBox(width: AppSpacing.sm),
            Text(
              label,
              style: TextStyle(fontSize: 13, color: theme.textSecondary),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.md),
        Text(
          value,
          style: AppTypography.title.copyWith(
            color: theme.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
        ClipRRect(
          borderRadius: BorderRadius.circular(3),
          child: LinearProgressIndicator(
            value: progressValue,
            backgroundColor: theme.isDark
                ? const Color(0xFF2A2A2A)
                : const Color(0xFFE8E8E8),
            valueColor: AlwaysStoppedAnimation<Color>(progressColor),
            minHeight: 6,
          ),
        ),
      ],
    );
  }
}

// ==================== 设备信息卡片 ====================
class _DeviceInfoCard extends StatelessWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _DeviceInfoCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    final isOnline = hat?.status == '1' || hat?.status == 'online';

    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 卡片标题
          Text(
            '设备信息',
            style: AppTypography.title.copyWith(
              color: theme.textPrimary,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // 设备内容
          Row(
            children: [
              // 设备图标
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: SpringColors.skyBlue.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.construction,
                  color: SpringColors.skyBlue,
                  size: 28,
                ),
              ),
              const SizedBox(width: AppSpacing.lg),
              // 设备信息
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      hat?.hatNumber ?? '安全帽',
                      style: AppTypography.title.copyWith(
                        color: theme.textPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      '绑定用户：${hat?.bindUserName ?? '未绑定'}',
                      style: TextStyle(fontSize: 13, color: theme.textTertiary),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      '所属分组：${hat?.bindGroup ?? '未分组'}',
                      style: TextStyle(fontSize: 13, color: theme.textTertiary),
                    ),
                  ],
                ),
              ),
              // 在线状态
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: isOnline
                      ? SpringColors.mintGreen.withValues(alpha: 0.1)
                      : SpringColors.cherryRed.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isOnline
                        ? SpringColors.mintGreen
                        : SpringColors.cherryRed,
                    width: 1,
                  ),
                ),
                child: Text(
                  isOnline ? '在线' : '离线',
                  style: AppTypography.button.copyWith(
                    color: isOnline
                        ? SpringColors.mintGreen
                        : SpringColors.cherryRed,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ==================== 当前位置卡片 ====================
class _LocationCard extends HookWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _LocationCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    // 解析经纬度
    LatLng? position;
    if (hat?.latitude != null && hat?.longitude != null) {
      final lat = double.tryParse(hat!.latitude!);
      final lng = double.tryParse(hat!.longitude!);
      if (lat != null && lng != null) {
        position = LatLng(lat, lng);
      }
    }

    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题栏
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '当前位置',
                style: AppTypography.title.copyWith(
                  color: theme.textPrimary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          // 分割线
          Divider(
            height: 1,
            color: theme.isDark
                ? const Color(0x1FFFFFFF)
                : const Color(0x14000000),
          ),
          const SizedBox(height: AppSpacing.lg),
          // 地图区域
          ClipRRect(
            borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
            child: Container(
              width: double.infinity,
              height: 180,
              child: position != null
                  ? AppMap(
                      initialCenter: position,
                      initialZoom: 16,
                      interactionFlags: InteractiveFlag.none,
                      children: [
                        MarkerLayer(
                          markers: [
                            Marker(
                              point: position,
                              width: 40,
                              height: 40,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: SpringColors.cherryRed.withValues(
                                    alpha: 0.2,
                                  ),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.location_on,
                                  color: SpringColors.cherryRed,
                                  size: 28,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    )
                  : Container(
                      color: theme.isDark
                          ? const Color(0xFF2A2A2A)
                          : const Color(0xFFF5F5F5),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.location_off,
                              color: theme.textTertiary,
                              size: 48,
                            ),
                            const SizedBox(height: AppSpacing.md),
                            Text(
                              '暂无位置信息',
                              style: AppTypography.body.copyWith(
                                color: theme.textTertiary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
            ),
          ),
          if (position != null) ...[
            const SizedBox(height: AppSpacing.lg),
            // 坐标信息
            Row(
              children: [
                // 左侧：图标
                Icon(Icons.gps_fixed, size: 16, color: SpringColors.skyBlue),

                // 间距
                const SizedBox(width: AppSpacing.sm),

                // 右侧：经度和纬度（使用 Expanded 包裹 Column）
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, // 让文字左对齐
                    children: [
                      Text(
                        '经度：${hat!.longitude}',
                        style: TextStyle(
                          fontSize: 13,
                          color: theme.textSecondary,
                        ),
                      ),
                      Text(
                        '纬度：${hat!.latitude}',
                        style: TextStyle(
                          fontSize: 13,
                          color: theme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
