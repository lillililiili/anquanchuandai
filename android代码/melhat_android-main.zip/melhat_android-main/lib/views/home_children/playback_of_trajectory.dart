import 'dart:async';

import 'package:flutter/material.dart';
import 'package:rolling_intelligence_headband/hooks/use_agent_page.dart';
import 'package:rolling_intelligence_headband/hooks/use_page_agent.dart';
import 'package:rolling_intelligence_headband/router/route_tree.dart';
import 'package:rolling_intelligence_headband/utils/app_logger.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import '../../api/hat.dart';
import '../../components/map_trajectory_player.dart';
import '../../components/trajectory_player_view.dart';
import '../../components/trajectory_player_controls.dart';
import '../../controllers/trajectory_player_controller.dart';
import '../../hooks/use_skeleton.dart';
import '../../hooks/use_theme.dart';
import '../../models/hat.dart';
import '../../models/hat_location_file_record.dart';
import '../../models/hat_location_record.dart';
import '../../models/trajectory_point.dart';
import '../../theme/theme.dart';
import '../../components/skeleton_view.dart';
import 'person_select.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

/// 轨迹回放页面
class PlaybackOfTrajectoryPage extends HookWidget {
  const PlaybackOfTrajectoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();
    final selectedHatId = useState<String?>(null);
    final selectedHatNumber = useState<String?>(null);
    final selectedUserName = useState<String?>(null);
    final startTime = useState<String>('');
    final endTime = useState<String>('');
    final showFullPlayer = useState<bool>(false);

    final agentController = useAgentPage(
      meta: RouteNode.playbackOfTrajectory,
      greetingMessage:
          "当前页面是轨迹回放页面，你可以查询特定安全帽在指定时间范围内的轨迹数据，并查看关联的视频。要求先选择人员、时间范围，然后执行executeQuery。查询结果会显示轨迹地图和关联视频。",
    );

    // 创建轨迹播放器控制器
    final playerController = useMemoized(() => TrajectoryPlayerController());

    // 检查查询条件是否有效
    final isValidQuery =
        selectedHatId.value != null &&
        startTime.value.isNotEmpty &&
        endTime.value.isNotEmpty;

    // 轨迹数据请求
    final trajectorySkeleton = useSkeleton<List<HatLocationRecord>>(
      emptyMsg: '暂无轨迹数据',
      immediate: false,
      isEmpty: (data) => data.isEmpty,
      request: () async {
        AppLogger.i(
          '执行轨迹数据请求: hatId=${selectedHatId.value}, startTime=${startTime.value}, endTime=${endTime.value}',
        );
        return await HatApi.queryHatLocationRecord(
          hatIds: [selectedHatId.value!],
          startTime: startTime.value,
          endTime: endTime.value,
        );
      },
    );

    // 当轨迹数据加载成功后，更新 controller
    final trajectoryContext = useContext();

    useEffect(() {
      final data = trajectorySkeleton.data;
      if (data.value != null && data.value!.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (trajectoryContext.mounted) {
            final points = TrajectoryPoint.fromList(data.value!);
            playerController.setPoints(points);
          }
        });
      }
      return null;
    }, [trajectorySkeleton.data.value != null]);

    // 视频数据请求（基于选择的 hatNumber 和时间范围）
    final videoSkeleton = useSkeleton<List<HatLocationFileRecord>>(
      emptyMsg: '暂无关联视频',
      isEmpty: (data) => data.isEmpty,
      request: () async {
        final hatNumber = selectedHatNumber.value;
        if (hatNumber == null || hatNumber.isEmpty) {
          return [];
        }
        // 调用 getRelatedFiles 获取关联视频文件
        return await HatApi.getRelatedFiles(
          hatNumber: hatNumber,
          startTime: startTime.value,
          endTime: endTime.value,
          fileType: 'video',
        );
      },
      immediate: false, // 不立即执行，等待轨迹数据加载完成
    );

    // 当轨迹数据加载成功后，加载视频数据
    useEffect(() {
      AppLogger.i(
        '轨迹状态变化，检查是否加载关联视频：status=${trajectorySkeleton.status.value}, selectedHatNumber=${selectedHatNumber.value}',
      );
      final status = trajectorySkeleton.status.value;
      if (status == SkeletonStatus.success && isValidQuery) {
        videoSkeleton.execute().ignore();
      }
      return null;
    }, [trajectorySkeleton.status.value, isValidQuery]);

    useEffect(() {
      agentController.completeEmptyInit();
      return null;
    }, []);

    usePageAgent(
      controller: agentController,
      toolName: 'executeQuery',
      executeFn: (params) async {
        // 这里可以根据 params 来执行不同的查询逻辑
        return trajectorySkeleton.execute();
      },
    );

    return Stack(
      children: [
        Scaffold(
          backgroundColor: theme.background,
          appBar: _buildAppBar(context, theme),
          body: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: AppSpacing.lg),
                // 1. 查询条件卡片
                _QueryConditionCard(
                  theme: theme,
                  agentController: agentController,
                  context: context,
                  selectedHatId: selectedHatId,
                  selectedHatNumber: selectedHatNumber,
                  selectedUserName: selectedUserName,
                  startTime: startTime,
                  endTime: endTime,
                  onQuery: () => trajectorySkeleton.execute().ignore(),
                ),
                // 2. 轨迹回放地图（仅查询后显示）
                if (isValidQuery &&
                    trajectorySkeleton.status.value != SkeletonStatus.idle) ...[
                  _TrajectoryMapCard(
                    theme: theme,
                    skeleton: trajectorySkeleton,
                    controller: playerController,
                    onFullScreen: () => showFullPlayer.value = true,
                  ),
                  // 3. 轨迹回放控制
                  _PlaybackControlCard(
                    theme: theme,
                    controller: playerController,
                  ),
                  // 4. 轨迹点关联视频
                  _RelatedVideoCard(theme: theme, skeleton: videoSkeleton),
                ],
                const SizedBox(height: AppSpacing.xl),
              ],
            ),
          ),
        ),
        // 全屏轨迹回放播放器（使用同一个控制器）
        MapTrajectoryPlayer(
          visible: showFullPlayer.value,
          onClose: () => showFullPlayer.value = false,
          trajectoryData: trajectorySkeleton.data.value ?? [],
          controller: playerController,
        ),
      ],
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context, ThemeColors theme) {
    return AppBar(
      backgroundColor: theme.background,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      leading: GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Container(
          margin: const EdgeInsets.all(AppSpacing.sm),
          decoration: BoxDecoration(
            color: SpringColors.mintGreen.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          ),
          child: const Icon(
            Icons.arrow_back_ios_new,
            size: 18,
            color: SpringColors.mintGreen,
          ),
        ),
      ),
      title: Text(
        '轨迹回放',
        style: AppTypography.headlineMedium.copyWith(color: theme.textPrimary),
      ),
      centerTitle: true,
    );
  }
}

// ==================== 查询条件卡片 ====================
class _QueryConditionCard extends HookWidget {
  final ThemeColors theme;
  final BuildContext context;
  final ValueNotifier<String?> selectedHatId;
  final ValueNotifier<String?> selectedHatNumber;
  final ValueNotifier<String?> selectedUserName;
  final ValueNotifier<String> startTime;
  final ValueNotifier<String> endTime;
  final VoidCallback onQuery;
  final PageAgentController agentController;

  const _QueryConditionCard({
    required this.theme,
    required this.context,
    required this.selectedHatId,
    required this.selectedHatNumber,
    required this.selectedUserName,
    required this.startTime,
    required this.endTime,
    required this.onQuery,
    required this.agentController,
  });

  @override
  Widget build(BuildContext context) {
    // 监听状态变化以触发重建
    final userName = useValueListenable(selectedUserName);

    final selectPerson = useCallback((String? personName) async {
      final result = await context.goto<dynamic>(
        RouteNode.hatSelect,
        extra: {
          'mode': SelectionMode.single,
          'personName': personName,
          'autoSelect': true,
        },
      );

      if (result is Hat) {
        final hat = result;
        AppLogger.i('选择安全帽成功: hatId=${hat.id}, hatNumber=${hat.hatNumber}');
        selectedHatId.value = hat.id;
        selectedHatNumber.value = hat.hatNumber;
        selectedUserName.value = hat.bindUserName ?? hat.hatNumber ?? '未知用户';
      }
      return result;
    }, [context]);

    usePageAgent(
      controller: agentController,
      toolName: 'selectPerson',
      executeFn: (params) async {
        // 这里可以根据 params 来执行不同的查询逻辑
        String? personName = params?['name'] as String?;
        return selectPerson(personName);
      },
    );

    usePageAgent(
      controller: agentController,
      toolName: 'selectDateRange',
      executeFn: (params) async {
        String start = params?['startTime'] as String? ?? '';
        String end = params?['endTime'] as String? ?? '';

        startTime.value = start;
        endTime.value = end;

        return true;
      },
    );

    // 检查查询条件是否有效
    final isValidQuery =
        selectedHatId.value != null &&
        startTime.value.isNotEmpty &&
        endTime.value.isNotEmpty;

    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '查询条件',
                style: AppTypography.title.copyWith(
                  color: theme.textPrimary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              // 查询按钮
              GestureDetector(
                onTap: isValidQuery ? onQuery : null,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.lg,
                    vertical: AppSpacing.sm,
                  ),
                  decoration: BoxDecoration(
                    color: isValidQuery
                        ? SpringColors.skyBlue.withValues(alpha: 0.15)
                        : (theme.isDark ? Colors.grey[700] : Colors.grey[300]),
                    borderRadius: BorderRadius.circular(
                      AppSpacing.radiusMedium,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.search,
                        size: 16,
                        color: isValidQuery
                            ? SpringColors.skyBlue
                            : (theme.isDark
                                  ? Colors.grey[500]
                                  : Colors.grey[600]),
                      ),
                      const SizedBox(width: AppSpacing.xs),
                      Text(
                        '查询',
                        style: TextStyle(
                          fontSize: 13,
                          color: isValidQuery
                              ? SpringColors.skyBlue
                              : (theme.isDark
                                    ? Colors.grey[500]
                                    : Colors.grey[600]),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          // 人员选择（单选）- 改为选择安全帽
          _buildQueryRow(
            label: '人员：',
            value: userName ?? '未选择',
            theme: theme,
            onTap: () async {
              selectPerson(null);
            },
          ),
          const SizedBox(height: AppSpacing.md),
          // 时间选择
          _buildQueryRow(
            label: '时间：',
            value: startTime.value.isNotEmpty
                ? _formatDisplayTime(startTime.value, endTime.value)
                : '选择时间范围',
            theme: theme,
            onTap: () => _selectDateRange(context, theme, startTime, endTime),
          ),
        ],
      ),
    );
  }

  Widget _buildQueryRow({
    required String label,
    required String value,
    required ThemeColors theme,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 14, color: theme.textSecondary),
          ),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 13,
                color: theme.textPrimary,
                fontWeight: FontWeight.w500,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
            ),
          ),
          const SizedBox(width: AppSpacing.xs),
          Icon(Icons.chevron_right, size: 18, color: theme.textTertiary),
        ],
      ),
    );
  }

  /// 选择日期范围
  Future<void> _selectDateRange(
    BuildContext context,
    ThemeColors theme,
    ValueNotifier<String> startTime,
    ValueNotifier<String> endTime,
  ) async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    // 解析现有值，如果有的话
    PickerDateRange? initialSelectedRange;
    if (startTime.value.isNotEmpty && endTime.value.isNotEmpty) {
      try {
        final startParts = startTime.value.split(' ');
        final endParts = endTime.value.split(' ');
        if (startParts.isNotEmpty && endParts.isNotEmpty) {
          final now = DateTime.now();
          final startDate = DateTime(
            now.year,
            int.parse(startParts[0].split('-')[0]),
            int.parse(startParts[0].split('-')[1]),
          );
          final endDate = DateTime(
            now.year,
            int.parse(endParts[0].split('-')[0]),
            int.parse(endParts[0].split('-')[1]),
          );
          initialSelectedRange = PickerDateRange(startDate, endDate);
        }
      } catch (_) {
        // 忽略解析错误
      }
    }

    final selectedRange = await showDialog<PickerDateRange>(
      context: context,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
            child: Container(
              width: 360,
              color: theme.cardBackground,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // 标题栏
                  Padding(
                    padding: const EdgeInsets.all(AppSpacing.lg),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '选择日期范围',
                          style: AppTypography.title.copyWith(
                            color: theme.textPrimary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.of(context).pop(),
                          child: Icon(
                            Icons.close,
                            size: 24,
                            color: theme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // 日期选择器
                  SfDateRangePicker(
                    view: DateRangePickerView.month,
                    selectionMode: DateRangePickerSelectionMode.range,
                    initialSelectedRange: initialSelectedRange,
                    minDate: DateTime(2020),
                    maxDate: today.add(const Duration(days: 1)),
                    todayHighlightColor: SpringColors.skyBlue,
                    startRangeSelectionColor: SpringColors.skyBlue,
                    endRangeSelectionColor: SpringColors.skyBlue,
                    rangeSelectionColor: SpringColors.skyBlue.withValues(
                      alpha: 0.2,
                    ),
                    selectionColor: SpringColors.skyBlue,
                    backgroundColor: theme.cardBackground,
                    headerStyle: DateRangePickerHeaderStyle(
                      backgroundColor: theme.cardBackground,
                      textStyle: TextStyle(
                        color: theme.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    monthViewSettings: DateRangePickerMonthViewSettings(
                      dayFormat: 'EEE',
                      viewHeaderStyle: DateRangePickerViewHeaderStyle(
                        backgroundColor: theme.cardBackground,
                        textStyle: TextStyle(
                          color: theme.textSecondary,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    monthCellStyle: DateRangePickerMonthCellStyle(
                      textStyle: TextStyle(color: theme.textPrimary),
                      todayTextStyle: TextStyle(
                        color: SpringColors.skyBlue,
                        fontWeight: FontWeight.bold,
                      ),
                      disabledDatesTextStyle: TextStyle(
                        color: theme.textTertiary.withValues(alpha: 0.5),
                      ),
                    ),
                    yearCellStyle: DateRangePickerYearCellStyle(
                      textStyle: TextStyle(color: theme.textPrimary),
                      todayTextStyle: TextStyle(
                        color: SpringColors.skyBlue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onSubmit: (Object? value) {
                      Navigator.of(context).pop(value as PickerDateRange?);
                    },
                    onCancel: () {
                      Navigator.of(context).pop(null);
                    },
                    showActionButtons: true,
                    confirmText: '确定',
                    cancelText: '取消',
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );

    if (selectedRange == null || !context.mounted) return;

    // 获取选中的开始和结束日期
    final startDate = selectedRange.startDate;
    final endDate = selectedRange.endDate ?? startDate;

    if (startDate == null) return;

    // 格式化日期：MM-DD（不显示年份）
    final startStr = _formatDate(startDate);
    final endStr = _formatDate(endDate!);

    // 设置开始时间为 08:00，结束时间为 18:00
    startTime.value = '$startStr 08:00';
    endTime.value = '$endStr 18:00';
  }

  /// 格式化日期为 YYYY-MM-DD
  String _formatDate(DateTime date) {
    final year = date.year;
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }

  /// 格式化显示时间（截掉年份，避免溢出）
  /// 输入格式: "YYYY-MM-DD HH:mm"
  /// 输出格式: "MM-DD HH:mm"
  String _formatDisplayTime(String startTime, String endTime) {
    // 去掉年份部分，只保留 MM-DD HH:mm
    final startDisplay = startTime.length >= 14
        ? startTime.substring(5)
        : startTime;
    final endDisplay = endTime.length >= 14 ? endTime.substring(5) : endTime;
    return '$startDisplay - $endDisplay';
  }
}

// ==================== 轨迹回放地图卡片 ====================
/// 使用 TrajectoryPlayerView 组件
class _TrajectoryMapCard extends HookWidget {
  final ThemeColors theme;
  final SkeletonBind<List<HatLocationRecord>> skeleton;
  final TrajectoryPlayerController controller;
  final VoidCallback onFullScreen;

  const _TrajectoryMapCard({
    required this.theme,
    required this.skeleton,
    required this.controller,
    required this.onFullScreen,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppSpacing.cardMargin,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题栏
          Padding(
            padding: AppSpacing.cardPaddingLarge,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '轨迹回放地图',
                  style: AppTypography.title.copyWith(
                    color: theme.textPrimary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                GestureDetector(
                  onTap: onFullScreen,
                  child: Row(
                    children: [
                      const Icon(
                        Icons.fullscreen,
                        size: 18,
                        color: SpringColors.skyBlue,
                      ),
                      const SizedBox(width: AppSpacing.xs),
                      const Text(
                        '全屏',
                        style: TextStyle(
                          fontSize: 13,
                          color: SpringColors.skyBlue,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // 地图区域（使用 TrajectoryPlayerView）
          SkeletonView.fromHook(skeleton, (data) {
            final points = TrajectoryPoint.fromList(data);
            return TrajectoryPlayerView(
              points: points,
              controller: controller,
              height: 200,
            );
          }),
          const SizedBox(height: AppSpacing.lg),
        ],
      ),
    );
  }
}

// ==================== 轨迹回放控制卡片 ====================
/// 使用新的 TrajectoryPlayerControls 组件
class _PlaybackControlCard extends HookWidget {
  final ThemeColors theme;
  final TrajectoryPlayerController controller;

  const _PlaybackControlCard({required this.theme, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: AppSpacing.cardMargin,
      child: TrajectoryPlayerControls(controller: controller),
    );
  }
}

// ==================== 轨迹点关联视频卡片 ====================
class _RelatedVideoCard extends HookWidget {
  final ThemeColors theme;
  final SkeletonBind<List<HatLocationFileRecord>> skeleton;

  const _RelatedVideoCard({required this.theme, required this.skeleton});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppSpacing.cardMargin,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题
          Padding(
            padding: AppSpacing.cardPaddingLarge,
            child: Text(
              '轨迹点关联视频',
              style: AppTypography.title.copyWith(
                color: theme.textPrimary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          // 视频列表（使用骨架屏）
          SkeletonView.fromHook(
            skeleton,
            (videos) => Column(
              children: videos
                  .map((video) => _VideoItem(video: video, theme: theme))
                  .toList(),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
        ],
      ),
    );
  }
}

class _VideoItem extends StatelessWidget {
  final HatLocationFileRecord video;
  final ThemeColors theme;

  const _VideoItem({required this.video, required this.theme});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (video.fileUrl != null && video.fileUrl!.isNotEmpty) {
          context.goto(
            RouteNode.videoPlayer,
            extra: {'url': video.fileUrl!, 'title': video.fileName ?? '视频播放'},
          );
        }
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.xl,
          vertical: AppSpacing.sm,
        ),
        child: Row(
          children: [
            // 视频缩略图
            Stack(
              children: [
                Container(
                  width: 120,
                  height: 90,
                  decoration: BoxDecoration(
                    color: theme.isDark
                        ? const Color(0xFF2A2A2A)
                        : const Color(0xFFF0F0F0),
                    borderRadius: BorderRadius.circular(
                      AppSpacing.radiusMedium,
                    ),
                  ),
                  child: Icon(
                    Icons.videocam,
                    size: 32,
                    color: theme.textTertiary,
                  ),
                ),
                // 播放按钮
                Positioned.fill(
                  child: Center(
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: SpringColors.skyBlue.withValues(alpha: 0.9),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.play_arrow,
                        size: 24,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: AppSpacing.lg),
            // 视频信息
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    video.fileName ?? '未命名视频',
                    style: AppTypography.body.copyWith(
                      color: theme.textPrimary,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    video.hatNumber ?? '未知设备',
                    style: TextStyle(fontSize: 13, color: theme.textSecondary),
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    video.uploadTime ?? '',
                    style: TextStyle(fontSize: 13, color: theme.textTertiary),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
