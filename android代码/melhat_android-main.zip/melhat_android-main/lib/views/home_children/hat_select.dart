import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:rolling_intelligence_headband/utils/app_logger.dart';
import '../../api/hat.dart';
import '../../components/pagination_list_view.dart';
import '../../hooks/use_pagination.dart';
import '../../hooks/use_theme.dart';
import '../../models/hat.dart';
import '../../theme/theme.dart';
import 'person_select.dart' show SelectionMode;

/// 安全帽选择页面
class HatSelectPage extends HookWidget {
  /// 选择模式，默认为单选
  final SelectionMode selectionMode;

  final String? personName;
  final List<String>? teamNames;
  final bool? autoSelect;

  const HatSelectPage({
    super.key,
    this.selectionMode = SelectionMode.single,
    this.personName,
    this.autoSelect,
    this.teamNames,
  });

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();

    // 搜索状态
    final searchText = useState('');
    final selectedStatus = useState<String?>(null);

    // 选中状态（使用 Set<Hat> 存储选中的 Hat 对象）
    final selectedHats = useState<Set<Hat>>({});

    // 分页 hook
    final pagination = usePaginationTable<Hat>(
      apiFun: (params) => HatApi.getHatPage(
        current: params['pageNum'],
        size: params['pageSize'],
        hatNumber: searchText.value.isEmpty ? null : searchText.value,
        status: selectedStatus.value,
      ),
      immediate: true,
      pageSize: 20,
      onComplete:
          ({
            required currentPage,
            required data,
            required isInitialLoad,
            required pageSize,
            required total,
          }) {
            if (!isInitialLoad || autoSelect != true) return;

            // teamNames 多选匹配
            if (teamNames != null && teamNames!.isNotEmpty) {
              final matched = data
                  .where((u) => teamNames!.contains(u.bindUserName))
                  .toList();
              AppLogger.i(
                'HatSelectPage: teamNames autoSelect, matched ${matched.length}/${teamNames!.length}',
              );
              Navigator.of(context).pop(matched.isNotEmpty ? matched : null);
              return;
            }

            // personName 单选匹配
            if (personName != null) {
              final matchedUser = data
                  .where((u) => u.bindUserName == personName)
                  .firstOrNull;
              AppLogger.i(
                'HatSelectPage: personName autoSelect, matched: $matchedUser',
              );
              Navigator.of(context).pop(matchedUser);
            }
          },
    );

    return Scaffold(
      backgroundColor: theme.background,
      appBar: _buildAppBar(context, theme),
      body: Column(
        children: [
          const SizedBox(height: AppSpacing.lg),
          // 搜索栏作为 header 放在 PaginationListView 中
          Expanded(
            child: PaginationListView<Hat>(
              bind: pagination,
              header: _buildSearchBar(
                theme: theme,
                searchText: searchText,
                selectedStatus: selectedStatus,
                onSearch: () => pagination.reload(),
              ),
              itemBuilder: (context, hat, index) => _HatListItem(
                hat: hat,
                isSelected: selectedHats.value.any((h) => h.id == hat.id),
                selectionMode: selectionMode,
                theme: theme,
                onSelected: (selected) {
                  final newSet = Set<Hat>.from(selectedHats.value);
                  if (selectionMode == SelectionMode.single) {
                    newSet.clear();
                    newSet.add(hat);
                  } else {
                    if (selected) {
                      newSet.add(hat);
                    } else {
                      newSet.removeWhere((h) => h.id == hat.id);
                    }
                  }
                  selectedHats.value = newSet;
                },
              ),
              separatorBuilder: (context, index) =>
                  const SizedBox(height: AppSpacing.sm),
              onRefresh: () => pagination.reload(),
              emptyMsg: '暂无安全帽数据',
            ),
          ),
          // 底部确认按钮
          _buildBottomButton(
            context: context,
            theme: theme,
            selectedHats: selectedHats,
            selectionMode: selectionMode,
          ),
        ],
      ),
    );
  }

  /// 构建顶部导航栏
  PreferredSizeWidget _buildAppBar(BuildContext context, ThemeColors theme) {
    return AppBar(
      backgroundColor: theme.background,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      leading: GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Container(
          margin: const EdgeInsets.all(AppSpacing.sm),
          decoration: BoxDecoration(
            color: SpringColors.mintGreen.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          ),
          child: const Icon(
            Icons.arrow_back_ios_new,
            size: 18,
            color: SpringColors.mintGreen,
          ),
        ),
      ),
      title: Text(
        '选择安全帽',
        style: AppTypography.headlineMedium.copyWith(color: theme.textPrimary),
      ),
      centerTitle: true,
    );
  }

  /// 构建搜索栏
  Widget _buildSearchBar({
    required ThemeColors theme,
    required ValueNotifier<String> searchText,
    required ValueNotifier<String?> selectedStatus,
    required VoidCallback onSearch,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.sm,
      ),
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: AppSpacing.sm,
      ),
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        boxShadow: AppShadows.light,
      ),
      child: Row(
        children: [
          // 状态筛选下拉框
          Container(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm),
            decoration: BoxDecoration(
              border: Border(right: BorderSide(color: theme.divider, width: 1)),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String?>(
                value: selectedStatus.value,
                hint: Text(
                  '全部状态',
                  style: TextStyle(fontSize: 14, color: theme.textSecondary),
                ),
                icon: Icon(
                  Icons.keyboard_arrow_down,
                  color: theme.textSecondary,
                  size: 18,
                ),
                items: [
                  const DropdownMenuItem<String?>(
                    value: null,
                    child: Text('全部状态'),
                  ),
                  DropdownMenuItem<String?>(
                    value: 'online',
                    child: Text(
                      '在线',
                      style: TextStyle(color: theme.textPrimary),
                    ),
                  ),
                  DropdownMenuItem<String?>(
                    value: 'offline',
                    child: Text(
                      '离线',
                      style: TextStyle(color: theme.textPrimary),
                    ),
                  ),
                ],
                onChanged: (value) {
                  selectedStatus.value = value;
                  onSearch();
                },
                dropdownColor: theme.cardBackground,
                style: TextStyle(fontSize: 14, color: theme.textPrimary),
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          // 搜索输入框
          Expanded(
            child: TextField(
              onChanged: (value) => searchText.value = value,
              onSubmitted: (_) => onSearch(),
              style: TextStyle(fontSize: 14, color: theme.textPrimary),
              decoration: InputDecoration(
                hintText: '搜索安全帽编号',
                hintStyle: TextStyle(fontSize: 14, color: theme.textTertiary),
                border: InputBorder.none,
                contentPadding: EdgeInsets.zero,
                isDense: true,
                filled: false,
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          // 搜索按钮
          GestureDetector(
            onTap: onSearch,
            child: Container(
              padding: const EdgeInsets.all(AppSpacing.sm),
              decoration: BoxDecoration(
                color: SpringColors.skyBlue.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
              ),
              child: const Icon(
                Icons.search,
                size: 20,
                color: SpringColors.skyBlue,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// 构建底部确认按钮
  Widget _buildBottomButton({
    required BuildContext context,
    required ThemeColors theme,
    required ValueNotifier<Set<Hat>> selectedHats,
    required SelectionMode selectionMode,
  }) {
    final selectedCount = selectedHats.value.length;
    final isEnabled = selectedCount > 0;

    return Container(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.lg,
        AppSpacing.md,
        AppSpacing.lg,
        AppSpacing.lg,
      ),
      decoration: BoxDecoration(
        color: theme.cardBackground,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: GestureDetector(
        onTap: isEnabled
            ? () {
                if (selectionMode == SelectionMode.single) {
                  // 单选：返回 Hat 对象
                  Navigator.of(context).pop(selectedHats.value.first);
                } else {
                  // 多选：返回 List<Hat>
                  Navigator.of(context).pop(selectedHats.value.toList());
                }
              }
            : null,
        child: AnimatedScale(
          scale: isEnabled ? 1 : 0.98,
          duration: AppSpacing.pressDuration,
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              gradient: isEnabled
                  ? const LinearGradient(
                      colors: [SpringColors.skyBlue, Color(0xFF2563EB)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    )
                  : null,
              color: isEnabled
                  ? null
                  : (theme.isDark ? Colors.grey[700] : Colors.grey[300]),
              borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
              boxShadow: isEnabled
                  ? [
                      BoxShadow(
                        color: SpringColors.skyBlue.withValues(alpha: 0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ]
                  : null,
            ),
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // 多选模式显示选中数量
                  if (isEnabled && selectionMode == SelectionMode.multiple)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.25),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '$selectedCount',
                        style: AppTypography.button.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  Text(
                    selectionMode == SelectionMode.single ? '确认' : '下一步',
                    style: AppTypography.button.copyWith(
                      color: isEnabled ? Colors.white : Colors.grey,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// 安全帽列表项
class _HatListItem extends HookWidget {
  final Hat hat;
  final bool isSelected;
  final SelectionMode selectionMode;
  final ThemeColors theme;
  final Function(bool) onSelected;

  const _HatListItem({
    required this.hat,
    required this.isSelected,
    required this.selectionMode,
    required this.theme,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final isPressed = useState(false);
    final primaryColor = SpringColors.mintGreen;

    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.sm,
      ),
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        border: Border.all(
          color: isSelected
              ? primaryColor.withValues(alpha: 0.3)
              : (theme.isDark
                    ? const Color(0x0DFFFFFF)
                    : const Color(0x0A000000)),
          width: isSelected ? 2 : 1,
        ),
        boxShadow: AppShadows.light,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
          onTap: () {
            if (selectionMode == SelectionMode.single) {
              onSelected(true);
            } else {
              onSelected(!isSelected);
            }
          },
          onTapDown: (_) => isPressed.value = true,
          onTapUp: (_) => isPressed.value = false,
          onTapCancel: () => isPressed.value = false,
          child: AnimatedScale(
            scale: isPressed.value ? AppSpacing.pressScale : 1,
            duration: AppSpacing.pressDuration,
            child: Padding(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Row(
                children: [
                  // 安全帽图标
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      gradient: isSelected
                          ? LinearGradient(
                              colors: [
                                primaryColor.withValues(alpha: 0.2),
                                primaryColor.withValues(alpha: 0.1),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : null,
                      color: isSelected
                          ? null
                          : (theme.isDark
                                ? const Color(0xFF2A2A2A)
                                : const Color(0xFFF5F5F5)),
                      borderRadius: BorderRadius.circular(
                        AppSpacing.radiusMedium,
                      ),
                    ),
                    child: Icon(
                      Icons.headset,
                      color: isSelected ? primaryColor : theme.textTertiary,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.lg),
                  // 安全帽信息
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 编号和状态
                        Row(
                          children: [
                            Text(
                              hat.hatNumber ?? '未知编号',
                              style: AppTypography.body.copyWith(
                                color: theme.textPrimary,
                                fontWeight: isSelected
                                    ? FontWeight.bold
                                    : FontWeight.w500,
                              ),
                            ),
                            const SizedBox(width: AppSpacing.sm),
                            // 状态标签
                            if (hat.status != null)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: hat.status == '1'
                                      ? SpringColors.mintGreen.withValues(
                                          alpha: 0.15,
                                        )
                                      : Colors.grey.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  hat.status == '1' ? '在线' : '已离线',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: hat.status == '1'
                                        ? SpringColors.mintGreen
                                        : Colors.grey,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: AppSpacing.xs),
                        // 绑定用户
                        if (hat.bindUserName != null)
                          Text(
                            '绑定用户：${hat.bindUserName}',
                            style: TextStyle(
                              fontSize: 13,
                              color: theme.textSecondary,
                            ),
                          ),
                        const SizedBox(height: AppSpacing.xs),
                        // 电量信息
                        if (hat.electricityUsage != null)
                          Row(
                            children: [
                              Icon(
                                Icons.battery_full,
                                size: 14,
                                color: hat.electricityColor != null
                                    ? Color(
                                        int.parse(
                                          hat.electricityColor!.replaceFirst(
                                            '#',
                                            '0xFF',
                                          ),
                                        ),
                                      )
                                    : theme.textTertiary,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '${hat.electricityUsage}%',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: theme.textTertiary,
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  // 选择指示器
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    switchInCurve: Curves.elasticOut,
                    switchOutCurve: Curves.easeIn,
                    child: selectionMode == SelectionMode.single
                        // 单选模式：圆形单选按钮
                        ? Container(
                            key: const ValueKey('single'),
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: isSelected
                                    ? SpringColors.skyBlue
                                    : theme.textTertiary.withValues(alpha: 0.3),
                                width: 2,
                              ),
                              color: isSelected
                                  ? SpringColors.skyBlue.withValues(alpha: 0.1)
                                  : Colors.transparent,
                            ),
                            child: isSelected
                                ? const Center(
                                    child: Icon(
                                      Icons.check,
                                      size: 16,
                                      color: SpringColors.skyBlue,
                                    ),
                                  )
                                : null,
                          )
                        // 多选模式：方形复选框
                        : isSelected
                        ? Container(
                            key: const ValueKey('selected'),
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [
                                  SpringColors.skyBlue,
                                  Color(0xFF2563EB),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(
                              Icons.check,
                              size: 18,
                              color: Colors.white,
                            ),
                          )
                        : Container(
                            key: const ValueKey('unselected'),
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: theme.textTertiary.withValues(
                                  alpha: 0.3,
                                ),
                                width: 2,
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
