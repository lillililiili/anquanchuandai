import 'package:flutter/material.dart';
import 'package:rolling_intelligence_headband/components/app_map.dart';
import 'package:rolling_intelligence_headband/components/map_fence.dart';
import 'package:rolling_intelligence_headband/hooks/use_agent_page.dart';
import 'package:rolling_intelligence_headband/hooks/use_dict.dart';
import 'package:rolling_intelligence_headband/hooks/use_page_agent.dart';
import 'package:rolling_intelligence_headband/hooks/use_page_agent_get_data.dart';
import 'package:rolling_intelligence_headband/router/route_tree.dart';
import 'package:rolling_intelligence_headband/utils/app_logger.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../../hooks/use_theme.dart';
import '../../theme/theme.dart';
import '../../api/fence.dart' as api;
import '../../models/fence.dart';

/// 电子围栏编辑/添加页面
class GeoFenceEditPage extends HookWidget {
  final String? fenceId;

  const GeoFenceEditPage({super.key, this.fenceId});

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();
    final isEditing = fenceId != null;

    // 页面 Agent 总控
    final pageController = useAgentPage(
      meta: RouteNode.geoFenceEdit,
      greetingMessage: '已进入围栏编辑页面，请设置围栏名称和类型，区域范围需手动在地图上绘制',
    );

    // 表单控制器
    final nameController = useTextEditingController();
    final fenceType = useState<String?>(null);
    final isLoading = useState(false);
    final isSaving = useState(false);

    // 字典数据
    final fenceTypeDict = useDict('elec_fence_type');

    // 地图编辑器状态
    final showMapEditor = useState(false);
    final fencePoints = useState<List<LatLng>>([]);

    // 绑定 AI 工具：设置围栏名称
    usePageAgent(
      controller: pageController,
      toolName: 'setFenceName',
      executeFn: (params) async {
        final name = params?['name'] as String?;
        if (name == null || name.isEmpty) {
          throw Exception('围栏名称不能为空');
        }
        nameController.text = name;
        return {'success': true, 'message': '围栏名称已设置为：$name'};
      },
    );

    // 绑定 AI 工具：设置围栏类型
    usePageAgent(
      controller: pageController,
      toolName: 'setFenceType',
      executeFn: (params) async {
        final type = params?['type'] as String?;
        if (type == null || type.isEmpty) {
          throw Exception('围栏类型不能为空');
        }
        final dictData = fenceTypeDict.data;
        final matched =
            dictData.where((e) => e.label == type || e.value == type).toList();
        AppLogger.i(
          "匹配围栏类型：fenceTypeDict=$dictData, type=$type, matched=$matched",
        );
        if (matched.isEmpty) {
          final available = dictData.map((e) => e.label).join('、');
          throw Exception('无效的围栏类型：$type，可选值：$available');
        }
        fenceType.value = matched.first.label;
        return {'success': true, 'message': '围栏类型已设置为：${matched.first.label}'};
      },
    );

    usePageAgentGetData(pageController, "formState", () {
      return {
        'fenceName': nameController.text,
        'fenceType': fenceType.value,
        'hasArea': fencePoints.value.isNotEmpty,
        'areaPointCount': fencePoints.value.length,
        'isEditing': isEditing,
        'fenceId': fenceId,
        'availableTypes':
            fenceTypeDict.data.map((e) => e.label).toList(),
      };
    });

    // 加载围栏详情
    final editContext = context;

    Future<void> loadFenceDetail() async {
      if (fenceId == null) return;

      isLoading.value = true;
      try {
        final fence = await api.FenceApi.getFenceById(fenceId!);
        if (!editContext.mounted) return;
        nameController.text = fence.fenceName ?? '';
        fenceType.value = fence.fenceType;
        // 回显围栏坐标
        if (fence.coordinates != null && fence.coordinates!.isNotEmpty) {
          fencePoints.value = fence.coordinates!
              .map((c) => LatLng(c.latitude ?? 0.0, c.longitude ?? 0.0))
              .toList();
        }
      } catch (e, t) {
        AppLogger.e("getFenceById", e, t);
        if (!editContext.mounted) return;
        ScaffoldMessenger.of(
          editContext,
        ).showSnackBar(SnackBar(content: Text('加载失败：$e')));
      } finally {
        if (editContext.mounted) {
          isLoading.value = false;
        }
      }
    }

    // 保存围栏
    Future<void> saveFence() async {
      if (nameController.text.isEmpty) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('请输入围栏名称')));
        return;
      }

      isSaving.value = true;
      try {
        final coordinates = fencePoints.value
            .map(
              (p) => Coordinates(latitude: p.latitude, longitude: p.longitude),
            )
            .toList();

        final fence = Fence(
          id: fenceId,
          fenceName: nameController.text,
          fenceType: fenceType.value,
          status: 1,
          coordinates: coordinates,
        );

        if (isEditing) {
          await api.FenceApi.updateFence(fence);
        } else {
          await api.FenceApi.saveFence(fence);
        }

        if (!editContext.mounted) return;
        Navigator.of(editContext).pop(true);
      } catch (e) {
        if (!editContext.mounted) return;
        ScaffoldMessenger.of(
          editContext,
        ).showSnackBar(SnackBar(content: Text('保存失败：$e')));
      } finally {
        if (editContext.mounted) {
          isSaving.value = false;
        }
      }
    }

    // 编辑模式加载详情
    useEffect(() {
      if (isEditing) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (editContext.mounted) {
            loadFenceDetail();
          }
        });
      }
      return null;
    }, []);

    // 等待字典数据加载完成后，通知 AI 页面就绪
    useEffect(() {
      if (fenceTypeDict.loaded) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (editContext.mounted) {
            AppLogger.d('围栏类型字典加载完成，页面准备就绪fenceTypeDict=${fenceTypeDict.data}');
            pageController.completeEmptyInit();
          }
        });
      }
      return null;
    }, [fenceTypeDict.loaded]);

    return Stack(
      children: [
        Scaffold(
          backgroundColor: theme.background,
          appBar: _buildAppBar(context, theme, isEditing),
          body: isLoading.value
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                  child: Column(
                    children: [
                      const SizedBox(height: AppSpacing.lg),
                      _GeoFenceForm(
                        theme: theme,
                        isEditing: isEditing,
                        nameController: nameController,
                        fenceType: fenceType,
                        fenceTypeDict: fenceTypeDict,
                        isSaving: isSaving,
                        onSave: saveFence,
                        showMapEditor: showMapEditor,
                        fencePoints: fencePoints,
                      ),
                    ],
                  ),
                ),
        ),
        // 地图编辑器
        MapFenceEditor(
          visible: showMapEditor.value,
          initialPoints: fencePoints.value,
          onClose: () => showMapEditor.value = false,
          onSave: (points) {
            fencePoints.value = points;
            showMapEditor.value = false;
          },
        ),
      ],
    );
  }

  PreferredSizeWidget _buildAppBar(
    BuildContext context,
    ThemeColors theme,
    bool isEditing,
  ) {
    return AppBar(
      backgroundColor: theme.background,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      leading: GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Container(
          margin: const EdgeInsets.all(AppSpacing.sm),
          decoration: BoxDecoration(
            color: SpringColors.mintGreen.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          ),
          child: const Icon(
            Icons.arrow_back_ios_new,
            size: 18,
            color: SpringColors.mintGreen,
          ),
        ),
      ),
      title: Text(
        isEditing ? '编辑围栏' : '添加围栏',
        style: AppTypography.headlineMedium.copyWith(color: theme.textPrimary),
      ),
      centerTitle: true,
    );
  }
}

// ==================== 表单内容 ====================
class _GeoFenceForm extends HookWidget {
  final ThemeColors theme;
  final bool isEditing;
  final TextEditingController nameController;
  final ValueNotifier<String?> fenceType;
  final DictState fenceTypeDict;
  final ValueNotifier<bool> isSaving;
  final VoidCallback onSave;
  final ValueNotifier<bool> showMapEditor;
  final ValueNotifier<List<LatLng>> fencePoints;

  const _GeoFenceForm({
    required this.theme,
    required this.isEditing,
    required this.nameController,
    required this.fenceType,
    required this.fenceTypeDict,
    required this.isSaving,
    required this.onSave,
    required this.showMapEditor,
    required this.fencePoints,
  });

  @override
  Widget build(BuildContext context) {
    final mapController = useMemoized(() => MapController());

    // 当围栏点变化时，自动调整地图视图
    useEffect(() {
      if (fencePoints.value.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          try {
            mapController.fitCamera(
              CameraFit.bounds(
                bounds: LatLngBounds.fromPoints(fencePoints.value),
                padding: const EdgeInsets.all(50),
              ),
            );
          } catch (_) {
            // 忽略控制器未挂载的错误
          }
        });
      }
      return null;
    }, [fencePoints.value]);

    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 围栏名称
          _buildFormItem(
            label: '围栏名称',
            child: _buildTextField(
              controller: nameController,
              hint: '请输入围栏名称',
              theme: theme,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // 围栏类型
          _buildFormItem(
            label: '围栏类型',
            child: _buildDropdownField(
              hint: '请选择围栏类型',
              value: fenceType.value,
              items: fenceTypeDict.data.map((e) => e.label ?? '').toList(),
              theme: theme,
              onChanged: (v) => fenceType.value = v,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // 设置区域范围
          _buildFormItem(
            label: '设置区域范围',
            child: _buildMapArea(theme: theme, mapController: mapController),
          ),
          const SizedBox(height: AppSpacing.xxl),
          // 底部按钮
          _buildBottomButtons(theme: theme, context: context),
          const SizedBox(height: AppSpacing.xl),
        ],
      ),
    );
  }

  Widget _buildFormItem({required String label, required Widget child}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTypography.body.copyWith(
            color: theme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: AppSpacing.md),
        child,
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required ThemeColors theme,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
        border: Border.all(
          color: theme.isDark
              ? const Color(0xFF3A3A3A)
              : const Color(0xFFE0E0E0),
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
        child: Container(
          color: theme.isDark ? const Color(0xFF2A2A2A) : Colors.white,
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(fontSize: 14, color: theme.textTertiary),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.lg,
                vertical: AppSpacing.md,
              ),
            ),
            style: TextStyle(fontSize: 14, color: theme.textPrimary),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdownField({
    required String hint,
    required String? value,
    required List<String> items,
    required ThemeColors theme,
    required void Function(String?) onChanged,
  }) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
        border: Border.all(
          color: theme.isDark
              ? const Color(0xFF3A3A3A)
              : const Color(0xFFE0E0E0),
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
        child: Container(
          color: theme.isDark ? const Color(0xFF2A2A2A) : Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: items.contains(value) ? value : null,
                hint: Text(
                  hint,
                  style: TextStyle(fontSize: 14, color: theme.textTertiary),
                ),
                items: items.map((item) {
                  return DropdownMenuItem(
                    value: item,
                    child: Text(
                      item,
                      style: TextStyle(fontSize: 14, color: theme.textPrimary),
                    ),
                  );
                }).toList(),
                onChanged: onChanged,
                icon: Icon(
                  Icons.keyboard_arrow_down,
                  size: 20,
                  color: theme.textSecondary,
                ),
                dropdownColor: theme.cardBackground,
                style: TextStyle(fontSize: 14, color: theme.textPrimary),
                isExpanded: true,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMapArea({
    required ThemeColors theme,
    required MapController mapController,
  }) {
    // 过滤有效坐标（纬度 -90~90，经度 -180~180）
    final validPoints = fencePoints.value.where((p) {
      return p.latitude >= -90 &&
          p.latitude <= 90 &&
          p.longitude >= -180 &&
          p.longitude <= 180;
    }).toList();
    final hasPoints = validPoints.isNotEmpty;

    return Stack(
      children: [
        Container(
          height: 240,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
            border: Border.all(
              color: theme.isDark
                  ? const Color(0xFF3A3A3A)
                  : const Color(0xFFE0E0E0),
              width: 1,
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
            child: AppMap(
              mapController: mapController,
              children: [
                // 显示绘制的围栏
                if (hasPoints && validPoints.length >= 3)
                  PolygonLayer(
                    polygons: [
                      Polygon(
                        points: validPoints,
                        color: SpringColors.skyBlue.withValues(alpha: 0.25),
                        borderColor: SpringColors.skyBlue,
                        borderStrokeWidth: 2,
                      ),
                    ],
                  ),
                if (hasPoints && validPoints.length >= 2)
                  PolylineLayer(
                    polylines: [
                      Polyline(
                        points: validPoints,
                        color: SpringColors.skyBlue,
                        strokeWidth: 3,
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
        // 编辑按钮
        Positioned(
          top: AppSpacing.sm,
          right: AppSpacing.sm,
          child: GestureDetector(
            onTap: () => showMapEditor.value = true,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: theme.cardBackground.withValues(alpha: 0.9),
                borderRadius: BorderRadius.circular(AppSpacing.radiusSmall),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 4,
                  ),
                ],
              ),
              child: Icon(
                Icons.edit_location_alt,
                size: 20,
                color: SpringColors.skyBlue,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBottomButtons({
    required ThemeColors theme,
    required BuildContext context,
  }) {
    return Row(
      children: [
        // 取消按钮
        Expanded(
          child: GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: theme.isDark
                    ? const Color(0xFF2A2A2A)
                    : const Color(0xFFF5F5F5),
                borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
              ),
              child: Center(
                child: Text(
                  '取消',
                  style: AppTypography.button.copyWith(
                    color: theme.textSecondary,
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: AppSpacing.lg),
        // 保存按钮
        Expanded(
          child: GestureDetector(
            onTap: isSaving.value ? null : onSave,
            child: AnimatedScale(
              scale: 1,
              duration: AppSpacing.pressDuration,
              child: Container(
                height: 48,
                decoration: BoxDecoration(
                  color: SpringColors.skyBlue,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
                ),
                child: Center(
                  child: isSaving.value
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text(
                          '保存',
                          style: AppTypography.button.copyWith(
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
