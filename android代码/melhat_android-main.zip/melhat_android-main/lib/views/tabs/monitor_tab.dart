import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:rolling_intelligence_headband/hooks/use_agent_page.dart';
import 'package:rolling_intelligence_headband/hooks/use_page_agent.dart';
import 'package:rolling_intelligence_headband/hooks/use_page_agent_get_data.dart';
import 'package:rolling_intelligence_headband/router/route_tree.dart';
import 'package:rolling_intelligence_headband/utils/app_logger.dart';
import '../../api/hat.dart';
import '../../api/intercom.dart';
import '../../components/skeleton_view.dart';
import '../../hooks/use_skeleton.dart';
import '../../hooks/use_theme.dart';
import '../../hooks/useAgoraRtcEngine.dart';
import '../../models/hat.dart';
import '../../models/agora_credentials.dart';
import '../../http/response/page.dart';
import '../../theme/theme_signal.dart';
import '../../theme/theme.dart';

class MonitorTab extends HookWidget {
  const MonitorTab({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();
    final isPlaying = useState(true);
    final volume = useState(0.7);
    final brightness = useState(0.8);
    final isFullscreen = useState(false);

    // 当前选中的设备
    final selectedHat = useState<Hat?>(null);

    // Agora RTC 状态
    final rtcState = useAgoraRtcEngine();
    final credentials = useState<AgoraCredentials?>(null);
    final isConnecting = useState(false);

    // 使用 skeleton hook 获取设备列表
    final skeleton = useSkeleton<DataPage<Hat>>(
      request: () => HatApi.getHatPage(current: 1, size: 20),
      isEmpty: (data) => data.isEmpty,
      onComplete: (data, {required isInitialLoad}) {
        if (!isInitialLoad) {
          return;
        }
        // 查找第一个在线设备（status = '1'）
        final list = data.records ?? [];

        final firstOnline = list.firstWhere(
          (hat) => hat.status == '1',
          orElse: () => list.first,
        );

        selectedHat.value = firstOnline;
      },
    );

    // 数据加载后默认选中第一个在线设备
    // useEffect(() {
    //   if (skeleton.status.value != SkeletonStatus.success) return null;

    //   final data = skeleton.data.value?.records ?? [];

    //   // 查找第一个在线设备（status = '1'）
    //   final firstOnline = data.firstWhere(
    //     (hat) => hat.status == '1',
    //     orElse: () => data.first,
    //   );

    //   selectedHat.value = firstOnline;
    //   return null;
    // }, [skeleton.status]);

    // 设备切换时连接频道
    useEffect(() {
      if (selectedHat.value == null) return null;

      Future<void> connectToDevice() async {
        if (selectedHat.value?.hatNumber == null) return;

        isConnecting.value = true;
        try {
          final creds = await IntercomApi.singleCall(
            hatNumber: selectedHat.value!.hatNumber,
            clientId: 'app_123',
            participant: selectedHat.value!.bindUserName,
          );
          if (!context.mounted) return;
          credentials.value = creds;
          await rtcState.joinChannel(creds);
        } catch (e) {
          AppLogger.e('monitor_tab connectToDevice error', e);
        } finally {
          if (context.mounted) {
            isConnecting.value = false;
          }
        }
      }

      connectToDevice();

      return () {
        unawaited(rtcState.leaveChannel());
      };
    }, [selectedHat.value]);

    // 滚动控制器
    final scrollController = useScrollController();

    // 设备切换（UI 和 Agent 共用）
    Future<void> handleSwitchDevice(Hat hat) async {
      selectedHat.value = hat;
      scrollController.animateTo(0, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    }

    // 进入监控详情（UI 和 Agent 共用）
    Future<void> handleEnterDetail() async {
      final hat = selectedHat.value;
      if (hat == null) return;
      final savedCreds = credentials.value;
      await rtcState.leaveChannel();
      if (!context.mounted) return;
      final credsJson = savedCreds != null ? jsonEncode(savedCreds.toJson()) : null;
      await context.goto(
        RouteNode.monitorDetail,
        params: {
          'deviceId': hat.id ?? '',
          'hatNumber': hat.hatNumber ?? '',
          if (credsJson != null) 'credentialsJson': credsJson,
        },
      );
      if (context.mounted && savedCreds != null) {
        AppLogger.d('返回监控页，重新连接频道');
        await Future.delayed(const Duration(milliseconds: 500));
        await rtcState.joinChannel(savedCreds);
      }
    }

    return _AgentScope(
      selectedHat: selectedHat,
      isConnecting: isConnecting,
      skeleton: skeleton,
      handleSwitchDevice: handleSwitchDevice,
      handleEnterDetail: handleEnterDetail,
      child: Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: theme.background,
      body: RefreshIndicator(
        onRefresh: () async {
          await skeleton.execute();
        },
        child: SingleChildScrollView(
          controller: scrollController,
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              // 1. 视频播放组件（带进入详情按钮）
              _buildVideoPlayerWithButton(
                context,
                isPlaying,
                volume,
                brightness,
                isFullscreen,
                selectedHat.value,
                rtcState,
                credentials.value,
                isConnecting.value,
                onEnterDetail: handleEnterDetail,
              ),
              // 2. 设备信息卡片
              _DeviceInfoCard(theme: theme, hat: selectedHat.value),
              // 3. 监控设备列表
              SkeletonView.fromHook(
                skeleton,
                (data) => _DeviceList(
                  theme: theme,
                  hats: data.records ?? [],
                  selectedHat: selectedHat.value,
                  onSelect: handleSwitchDevice,
                ),
              ),
              // 底部间距（避免被悬浮导航栏遮挡）
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    ),
    );
  }

  Widget _buildVideoPlayerWithButton(
    BuildContext context,
    ValueNotifier<bool> isPlaying,
    ValueNotifier<double> volume,
    ValueNotifier<double> brightness,
    ValueNotifier<bool> isFullscreen,
    Hat? selectedHat,
    AgoraRtcState rtcState,
    AgoraCredentials? credentials,
    bool isConnecting, {
    required Future<void> Function() onEnterDetail,
  }) {
    final statusBarHeight = MediaQuery.of(context).padding.top;
    final topOffset = statusBarHeight + 12;

    return Stack(
      children: [
        _VideoPlayerSection(
          isPlaying: isPlaying,
          volume: volume,
          brightness: brightness,
          isFullscreen: isFullscreen,
          onPlayPause: () => isPlaying.value = !isPlaying.value,
          onVolumeChanged: (v) => volume.value = v,
          onBrightnessChanged: (b) => brightness.value = b,
          onFullscreenToggle: () => isFullscreen.value = !isFullscreen.value,
          rtcState: rtcState,
          credentials: credentials,
          isConnecting: isConnecting,
        ),
        Positioned(
          top: topOffset,
          right: 12,
          child: GestureDetector(
            onTap: onEnterDetail,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.info_outline, size: 14, color: Colors.white),
                  SizedBox(width: 4),
                  Text(
                    '进入详情',
                    style: TextStyle(color: Colors.white, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
        ),
        // 实时标签
        Positioned(
          top: topOffset,
          left: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.circle, size: 8, color: Colors.white),
                SizedBox(width: 4),
                Text('实时', style: TextStyle(color: Colors.white, fontSize: 12)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// Agent 适配层
class _AgentScope extends HookWidget {
  final Widget child;
  final ValueNotifier<Hat?> selectedHat;
  final ValueNotifier<bool> isConnecting;
  final SkeletonBind<DataPage<Hat>> skeleton;
  final Future<void> Function(Hat) handleSwitchDevice;
  final Future<void> Function() handleEnterDetail;

  const _AgentScope({
    required this.child,
    required this.selectedHat,
    required this.isConnecting,
    required this.skeleton,
    required this.handleSwitchDevice,
    required this.handleEnterDetail,
  });

  @override
  Widget build(BuildContext context) {
    final pageController = useAgentPage(meta: RouteNode.homeTab3);

    // 工具1：查询监控设备列表
    usePageAgent(
      controller: pageController,
      toolName: 'queryMonitorDevices',
      executeFn: (params) async {
        final records = skeleton.data.value?.records ?? [];
        return {
          'devices': records
              .map((h) => {
                    'hatNumber': h.hatNumber,
                    'bindUserName': h.bindUserName,
                    'bindGroup': h.bindGroup,
                    'status': h.status,
                  })
              .toList(),
          'total': records.length,
          'selectedHatNumber': selectedHat.value?.hatNumber,
        };
      },
    );

    // 工具2：切换到指定监控设备
    usePageAgent(
      controller: pageController,
      toolName: 'selectMonitorDevice',
      executeFn: (params) async {
        final hatNumber = params?['hatNumber'] as String?;
        final bindUserName = params?['bindUserName'] as String?;
        if (hatNumber == null && bindUserName == null) {
          return {'success': false, 'message': '请提供设备编号或绑定人员姓名'};
        }
        final records = skeleton.data.value?.records ?? [];
        final target = records.firstWhere(
          (h) => (hatNumber != null && h.hatNumber == hatNumber) ||
              (bindUserName != null && h.bindUserName == bindUserName),
          orElse: () => Hat(),
        );
        if (target.hatNumber == null) {
          return {'success': false, 'message': '未找到匹配的设备'};
        }
        await handleSwitchDevice(target);
        return {
          'success': true,
          'message': '已切换到设备：${target.hatNumber}（${target.bindUserName ?? '未绑定'}）',
        };
      },
    );

    // 工具3：进入当前设备的监控详情
    usePageAgent(
      controller: pageController,
      toolName: 'enterMonitorDetail',
      executeFn: (params) async {
        if (selectedHat.value == null) {
          return {'success': false, 'message': '当前没有选中设备'};
        }
        await handleEnterDetail();
        return {'success': true, 'message': '已进入设备 ${selectedHat.value!.hatNumber} 的监控详情'};
      },
    );

    // 暴露页面状态给 AI
    usePageAgentGetData(pageController, 'monitorState', () {
      final hat = selectedHat.value;
      final records = skeleton.data.value?.records ?? [];
      return {
        'selectedHat': hat != null
            ? {
                'hatNumber': hat.hatNumber,
                'bindUserName': hat.bindUserName,
                'status': hat.status,
                'electricityUsage': hat.electricityUsage,
              }
            : null,
        'deviceCount': records.length,
        'isConnecting': isConnecting.value,
        'onlineCount': records.where((h) => h.status == '1').length,
      };
    });

    // 通知 AI 页面就绪
    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) {
          pageController.completeEmptyInit();
        }
      });
      return null;
    }, []);

    return child;
  }
}

// 视频播放组件
class _VideoPlayerSection extends StatelessWidget {
  final ValueNotifier<bool> isPlaying;
  final ValueNotifier<double> volume;
  final ValueNotifier<double> brightness;
  final ValueNotifier<bool> isFullscreen;
  final VoidCallback onPlayPause;
  final Function(double) onVolumeChanged;
  final Function(double) onBrightnessChanged;
  final VoidCallback onFullscreenToggle;
  final AgoraRtcState rtcState;
  final AgoraCredentials? credentials;
  final bool isConnecting;

  final bool showControls = false; // 控制栏显示开关（暂时隐藏进度条、暂停、亮度、全屏等）

  const _VideoPlayerSection({
    required this.isPlaying,
    required this.volume,
    required this.brightness,
    required this.isFullscreen,
    required this.onPlayPause,
    required this.onVolumeChanged,
    required this.onBrightnessChanged,
    required this.onFullscreenToggle,
    required this.rtcState,
    required this.credentials,
    required this.isConnecting,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final videoHeight = screenWidth * 0.75;

    // 获取第一个远端用户
    final remoteUser = rtcState.remoteUsers.isNotEmpty
        ? rtcState.remoteUsers.values.first
        : null;

    return Container(
      width: double.infinity,
      height: videoHeight,
      color: Colors.black,
      child: Stack(
        children: [
          // 视频播放区域
          Positioned.fill(
            child: isConnecting
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const CircularProgressIndicator(color: Colors.white54),
                        const SizedBox(height: 16),
                        Text(
                          '正在连接设备...',
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  )
                : remoteUser != null && remoteUser.hasVideo
                ? AgoraVideoView(
                    controller: VideoViewController.remote(
                      rtcEngine: rtcState.engine!,
                      canvas: VideoCanvas(uid: remoteUser.uid),
                      connection: RtcConnection(
                        channelId: credentials?.channelName ?? '',
                      ),
                    ),
                  )
                : Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          remoteUser != null
                              ? Icons.videocam_off
                              : Icons.videocam_outlined,
                          size: 80,
                          color: Colors.white54,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          remoteUser != null ? '等待视频流...' : '等待设备接入...',
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
          // 播放/暂停提示（隐藏）
          if (showControls && !isPlaying.value)
            Container(
              color: Colors.black54,
              child: const Center(
                child: Icon(
                  Icons.pause_circle_outline,
                  size: 80,
                  color: Colors.white,
                ),
              ),
            ),
          // 亮度调节层（隐藏）
          if (showControls)
            Container(
              color: Colors.black.withValues(
                alpha: (1 - brightness.value) * 0.5,
              ),
            ),
          // 控制栏（隐藏）
          if (showControls)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
                child: Column(
                  children: [
                    // 进度条（占位）
                    SliderTheme(
                      data: SliderThemeData(
                        trackHeight: 4,
                        thumbShape: const RoundSliderThumbShape(
                          enabledThumbRadius: 6,
                        ),
                        overlayShape: const RoundSliderOverlayShape(
                          overlayRadius: 14,
                        ),
                        activeTrackColor: Colors.blue,
                        inactiveTrackColor: Colors.white30,
                        thumbColor: Colors.blue,
                        overlayColor: Colors.blue.withValues(alpha: 0.2),
                      ),
                      child: Slider(
                        value: 0.6,
                        onChanged: (v) {},
                        activeColor: Colors.blue,
                        inactiveColor: Colors.white30,
                      ),
                    ),
                    // 控制按钮
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            // 播放/暂停按钮
                            IconButton(
                              icon: Icon(
                                isPlaying.value
                                    ? Icons.pause
                                    : Icons.play_arrow,
                                color: Colors.white,
                              ),
                              onPressed: onPlayPause,
                            ),
                            // 音量控制
                            PopupMenuButton<double>(
                              icon: Icon(
                                volume.value > 0.5
                                    ? Icons.volume_up
                                    : volume.value > 0
                                    ? Icons.volume_down
                                    : Icons.volume_off,
                                color: Colors.white,
                              ),
                              onSelected: onVolumeChanged,
                              itemBuilder: (context) => [
                                const PopupMenuItem(
                                  value: 1.0,
                                  child: Text('100%'),
                                ),
                                const PopupMenuItem(
                                  value: 0.7,
                                  child: Text('70%'),
                                ),
                                const PopupMenuItem(
                                  value: 0.5,
                                  child: Text('50%'),
                                ),
                                const PopupMenuItem(
                                  value: 0.3,
                                  child: Text('30%'),
                                ),
                                const PopupMenuItem(
                                  value: 0.0,
                                  child: Text('静音'),
                                ),
                              ],
                            ),
                            // 亮度控制
                            PopupMenuButton<double>(
                              icon: Icon(
                                brightness.value > 0.7
                                    ? Icons.brightness_high
                                    : brightness.value > 0.3
                                    ? Icons.brightness_medium
                                    : Icons.brightness_low,
                                color: Colors.white,
                              ),
                              onSelected: onBrightnessChanged,
                              itemBuilder: (context) => [
                                const PopupMenuItem(
                                  value: 1.0,
                                  child: Text('100%'),
                                ),
                                const PopupMenuItem(
                                  value: 0.8,
                                  child: Text('80%'),
                                ),
                                const PopupMenuItem(
                                  value: 0.5,
                                  child: Text('50%'),
                                ),
                                const PopupMenuItem(
                                  value: 0.3,
                                  child: Text('30%'),
                                ),
                              ],
                            ),
                          ],
                        ),
                        // 全屏按钮
                        IconButton(
                          icon: Icon(
                            isFullscreen.value
                                ? Icons.fullscreen_exit
                                : Icons.fullscreen,
                            color: Colors.white,
                          ),
                          onPressed: onFullscreenToggle,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// 设备信息卡片
class _DeviceInfoCard extends StatelessWidget {
  final ThemeColors theme;
  final Hat? hat;

  const _DeviceInfoCard({required this.theme, this.hat});

  @override
  Widget build(BuildContext context) {
    // 从 Hat 数据中提取显示值
    final electricity = hat?.electricityUsage;
    final storage = hat?.storageUsage;
    final cpu = hat?.cpuUsage;

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: theme.textPrimary.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '设备信息',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: theme.textPrimary,
                ),
              ),
              if (hat != null)
                Text(
                  hat!.hatNumber ?? '未知设备',
                  style: TextStyle(fontSize: 14, color: theme.textSecondary),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              // 电量
              _InfoItem(
                icon: Icons.battery_full,
                label: '电量',
                value: electricity != null ? '${electricity.toInt()}%' : '--',
                iconColor: _getBatteryColor(electricity),
                theme: theme,
              ),
              // 存储空间
              _InfoItem(
                icon: Icons.storage,
                label: '存储空间',
                value: storage != null ? '${storage.toInt()}%' : '--',
                iconColor: Colors.blue,
                theme: theme,
              ),
              // CPU 使用率（替代运行时长）
              _InfoItem(
                icon: Icons.memory,
                label: 'CPU',
                value: cpu != null ? '${cpu.toInt()}%' : '--',
                iconColor: Colors.orange,
                theme: theme,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color _getBatteryColor(num? electricity) {
    if (electricity == null) return Colors.grey;
    if (electricity > 50) return Colors.green;
    if (electricity > 20) return Colors.orange;
    return Colors.red;
  }
}

// 信息项组件
class _InfoItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color iconColor;
  final ThemeColors theme;

  const _InfoItem({
    required this.icon,
    required this.label,
    required this.value,
    required this.iconColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: iconColor.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: iconColor, size: 28),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: theme.textPrimary,
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 12, color: theme.textSecondary)),
      ],
    );
  }
}

// 监控设备列表
class _DeviceList extends StatelessWidget {
  final ThemeColors theme;
  final List<Hat> hats;
  final Hat? selectedHat;
  final Function(Hat) onSelect;

  const _DeviceList({
    required this.theme,
    required this.hats,
    required this.selectedHat,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: theme.textPrimary.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '监控设备列表',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: theme.textPrimary,
            ),
          ),
          const SizedBox(height: 12),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: hats.length,
            separatorBuilder: (context, index) =>
                Divider(height: 1, color: theme.divider),
            itemBuilder: (context, index) {
              final hat = hats[index];
              final isSelected = selectedHat?.id == hat.id;
              return _DeviceListItem(
                hat: hat,
                theme: theme,
                isSelected: isSelected,
                onTap: () => onSelect(hat),
              );
            },
          ),
        ],
      ),
    );
  }
}

// 设备列表项
class _DeviceListItem extends StatelessWidget {
  final Hat hat;
  final ThemeColors theme;
  final bool isSelected;
  final VoidCallback onTap;

  const _DeviceListItem({
    required this.hat,
    required this.theme,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isOnline = hat.status == '1' || hat.status == 'online';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          // 设备类型图标
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.blue.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.videocam, color: Colors.blue, size: 24),
          ),
          const SizedBox(width: 12),
          // 设备信息
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hat.hatNumber ?? '未知设备',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: theme.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${hat.bindUserName ?? '未绑定'} · ${hat.bindGroup ?? '未分组'}',
                  style: TextStyle(fontSize: 12, color: theme.textSecondary),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: isOnline ? Colors.green : Colors.red,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      isOnline ? '在线' : '离线',
                      style: TextStyle(
                        fontSize: 12,
                        color: isOnline ? Colors.green : Colors.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // 切换播放按钮
          ElevatedButton(
            onPressed: onTap,
            style: ElevatedButton.styleFrom(
              backgroundColor: isSelected ? Colors.green : Colors.blue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(isSelected ? '当前' : '切换'),
          ),
        ],
      ),
    );
  }
}
