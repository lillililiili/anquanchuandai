import 'package:flutter/material.dart';
import 'package:rolling_intelligence_headband/api/user.dart';
import 'package:rolling_intelligence_headband/models/app_statistics.dart';
import 'package:rolling_intelligence_headband/models/user.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:rolling_intelligence_headband/router/route_tree.dart';
import '../../hooks/use_agent_page.dart';
import '../../hooks/use_page_agent.dart';
import '../../hooks/use_theme.dart';
import '../../hooks/auto_loading.dart';
import '../../store/user_store.dart';
import '../../theme/theme.dart';
import '../../theme/theme_signal.dart';
import '../../utils/app_logger.dart';
import 'package:voice_recognizer/voice_recognizer.dart';

/// 我的页面
class MineTabPage extends HookWidget {
  const MineTabPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = useTheme();
    final userStore = useUserStore();

    // 1. 页面总控中心
    final pageController = useAgentPage(
      meta: RouteNode.homeTab4,
      greetingMessage: '已进入我的页面，我可以帮您查看个人信息或退出登录',
      expectedComponents: {'statistics'},
    );

    // 使用 useAutoLoading 管理退出登录的 loading 状态
    final logoutState = useAutoLoading();

    // 统计数据
    final statistics = useState<AppStatistics?>(null);
    final isLoading = useState(true);

    // 注册 getUserInfo 工具
    usePageAgent(
      controller: pageController,
      toolName: 'getUserInfo',
      executeFn: (params) async {
        return userStore.userInfo?.toJson() ?? {};
      },
    );

    // 注册 getStatistics 工具
    usePageAgent(
      controller: pageController,
      toolName: 'getStatistics',
      executeFn: (params) async {
        return {
          'hatCount': statistics.value?.hatCount ?? 0,
          'alarmCount': statistics.value?.alarmCount ?? 0,
        };
      },
    );

    // 注册 logout 工具
    usePageAgent(
      controller: pageController,
      toolName: 'logout',
      executeFn: (params) async {
        await userStore.logout();
        return {'success': true};
      },
    );

    // 获取统计数据
    final mineContext = useContext();
    useEffect(() {
      Future<void> fetchStatistics() async {
        try {
          final data = await UserApi.getAppStatistics();
          if (!mineContext.mounted) return;
          statistics.value = data;
          pageController.completeInit(componentId: 'statistics');
        } catch (e) {
          AppLogger.e('getAppStatistics error', e);
          pageController.completeInit(componentId: 'statistics');
        } finally {
          if (mineContext.mounted) {
            isLoading.value = false;
          }
        }
      }

      fetchStatistics();

      return null;
    }, []);

    Future<void> handleLogout() async {
      await logoutState.run(userStore.logout());
      // 退出成功后跳转到登录页
      // if (context.mounted) {
      //   context.replace(RouteNode.login);
      // }
    }

    return Scaffold(
      backgroundColor: theme.background,
      extendBodyBehindAppBar: true,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // 1. 信息卡片
              userStore.userInfo != null
                  ? _UserInfoCard(
                      userInfo: userStore.userInfo!,
                      theme: theme,
                      statistics: statistics.value,
                      isLoading: isLoading.value,
                    )
                  : const SizedBox.shrink(),
              // 2. 功能列表
              _FunctionListSection(
                theme: theme,
                onLogout: () =>
                    _showLogoutDialog(context, logoutState, handleLogout),
                onClearModel: () => _showClearModelDialog(context),
                isLoading: logoutState.loading,
              ),
              // 底部间距（避免被悬浮导航栏遮挡）
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }

  void _showClearModelDialog(BuildContext context) {
    final theme = ThemeModeSignal.themeColorsSignal.value;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
        ),
        backgroundColor: theme.cardBackground,
        title: Text('清除语音模型', style: TextStyle(color: theme.textPrimary)),
        content: Text(
          '将删除已下载的语音识别模型文件，下次使用语音功能时需重新下载。',
          style: TextStyle(color: theme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('取消', style: TextStyle(color: theme.textTertiary)),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await ModelDownloadService.instance.deleteModel();
              VoiceRecognizerRegistry.instance.reset();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('语音模型已清除')),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: SpringColors.sproutYellow,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
              ),
            ),
            child: const Text('确认清除'),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog(
    BuildContext context,
    AutoLoadingState logoutState,
    VoidCallback onConfirm,
  ) {
    final theme = ThemeModeSignal.themeColorsSignal.value;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
        ),
        backgroundColor: theme.cardBackground,
        title: Text('确认退出', style: TextStyle(color: theme.textPrimary)),
        content: Text(
          '确定要退出当前账号吗？',
          style: TextStyle(color: theme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('取消', style: TextStyle(color: theme.textTertiary)),
          ),
          ElevatedButton(
            onPressed: logoutState.loading ? null : onConfirm,
            style: ElevatedButton.styleFrom(
              backgroundColor: SpringColors.cherryRed,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
              ),
            ),
            child: logoutState.loading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('退出'),
          ),
        ],
      ),
    );
  }
}

// ==================== 用户信息卡片 ====================
class _UserInfoCard extends StatelessWidget {
  final UserInfo userInfo;
  final ThemeColors theme;
  final AppStatistics? statistics;
  final bool isLoading;

  const _UserInfoCard({
    required this.userInfo,
    required this.theme,
    this.statistics,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    final mintGreen = SpringColors.getMintColor(theme.isDark);

    return Container(
      margin: AppSpacing.cardMargin,
      padding: AppSpacing.cardPaddingLarge,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        children: [
          // 头像和基本信息
          Row(
            children: [
              // 头像
              Container(
                width: AppSpacing.avatarSize,
                height: AppSpacing.avatarSize,
                decoration: BoxDecoration(
                  color: mintGreen.withValues(
                    alpha: AppSpacing.iconBackgroundAlphaActive,
                  ),
                  shape: BoxShape.circle,
                ),
                child: ClipOval(
                  child: Image.network(
                    userInfo.avatar,
                    fit: BoxFit.cover,
                    errorBuilder: (context, _, _) => Icon(
                      Icons.person,
                      size: AppSpacing.avatarIconSize,
                      color: mintGreen,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: AppSpacing.lg),
              // 姓名和部门
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      userInfo.nickName,
                      style: TextStyle(
                        color: theme.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: SpringColors.skyBlue.withValues(
                          alpha: AppSpacing.iconBackgroundAlpha,
                        ),
                        borderRadius: BorderRadius.circular(
                          AppSpacing.radiusSmall,
                        ),
                      ),
                      child: Text(
                        userInfo.remark,
                        style: const TextStyle(
                          color: SpringColors.skyBlue,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.xl),
          // 数据统计
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _StatItem(
                icon: Icons.devices_outlined,
                value: isLoading ? "--" : "${statistics?.hatCount ?? 0}",
                label: '管理安全帽',
                color: SpringColors.skyBlue,
                theme: theme,
              ),
              _StatItem(
                icon: Icons.warning_amber_outlined,
                value: isLoading ? "--" : "${statistics?.alarmCount ?? 0}",
                label: '处理告警',
                color: SpringColors.cherryRed,
                theme: theme,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color color;
  final ThemeColors theme;

  const _StatItem({
    required this.icon,
    required this.value,
    required this.label,
    required this.color,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: AppSpacing.statIconSize,
          height: AppSpacing.statIconSize,
          decoration: BoxDecoration(
            color: color.withValues(alpha: AppSpacing.iconBackgroundAlpha),
            borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
          ),
          child: Icon(icon, color: color, size: AppSpacing.statIconIconSize),
        ),
        const SizedBox(height: AppSpacing.sm),
        Text(
          value,
          style: TextStyle(
            color: theme.textPrimary,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: theme.textSecondary, fontSize: 12)),
      ],
    );
  }
}

// ==================== 功能列表区域 ====================
class _FunctionListSection extends StatelessWidget {
  final ThemeColors theme;
  final VoidCallback? onLogout;
  final VoidCallback? onClearModel;
  final bool isLoading;

  const _FunctionListSection({
    required this.theme,
    this.onLogout,
    this.onClearModel,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppSpacing.cardMargin,
      decoration: BoxDecoration(
        color: theme.cardBackground,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLarge),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        children: [
          _FunctionItem(
            icon: Icons.security,
            iconColor: SpringColors.mintGreen,
            title: '我的安全帽',
            subtitle: '设备绑定与管理',
            theme: theme,
            onTap: () => context.goto(RouteNode.mySafetyHat),
          ),
          _Divider(theme: theme),
          _FunctionItem(
            icon: Icons.smart_toy,
            iconColor: SpringColors.skyBlue,
            title: 'AI 配置',
            subtitle: '配置 AI 服务参数',
            theme: theme,
            onTap: () => context.goto(RouteNode.aiConfig),
          ),
          _Divider(theme: theme),
          _FunctionItem(
            icon: Icons.delete_sweep_outlined,
            iconColor: SpringColors.sproutYellow,
            title: '清除语音模型',
            subtitle: '删除已下载的语音识别模型文件',
            theme: theme,
            onTap: onClearModel,
          ),
          _Divider(theme: theme),
          _FunctionItem(
            icon: Icons.logout,
            iconColor: SpringColors.cherryRed,
            title: '退出登录',
            subtitle: '安全退出账号',
            isDestructive: true,
            theme: theme,
            isLoading: isLoading,
            onTap: onLogout,
          ),
        ],
      ),
    );
  }
}

class _FunctionItem extends HookWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final bool isDestructive;
  final VoidCallback? onTap;
  final ThemeColors theme;
  final bool isLoading;

  const _FunctionItem({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    this.isDestructive = false,
    this.onTap,
    required this.theme,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    final isPressed = useState(false);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => isPressed.value = true,
      onTapUp: (_) {
        isPressed.value = false;
        if (!isLoading) {
          onTap?.call();
        }
      },
      onTapCancel: () => isPressed.value = false,
      child: AnimatedScale(
        scale: isPressed.value ? AppSpacing.pressScale : 1,
        duration: AppSpacing.pressDuration,
        child: Container(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Row(
            children: [
              // 图标
              Container(
                width: AppSpacing.listIconSize,
                height: AppSpacing.listIconSize,
                decoration: BoxDecoration(
                  color: iconColor.withValues(
                    alpha: AppSpacing.iconBackgroundAlpha,
                  ),
                  borderRadius: BorderRadius.circular(AppSpacing.radiusMedium),
                ),
                child: isLoading
                    ? const Center(
                        child: SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    : Icon(
                        icon,
                        color: iconColor,
                        size: AppSpacing.listIconIconSize,
                      ),
              ),
              const SizedBox(width: AppSpacing.md),
              // 标题和副标题
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: isDestructive
                            ? SpringColors.cherryRed
                            : theme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 12,
                        color: theme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              // 箭头
              Icon(Icons.chevron_right, color: theme.divider, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  final ThemeColors theme;

  const _Divider({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Divider(
      height: 1,
      thickness: 1,
      color: theme.divider,
      indent: AppSpacing.listIconSize + AppSpacing.md,
      endIndent: AppSpacing.lg,
    );
  }
}
