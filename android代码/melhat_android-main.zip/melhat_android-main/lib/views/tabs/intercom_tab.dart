import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:rolling_intelligence_headband/hooks/use_agent_page.dart';
import 'package:rolling_intelligence_headband/hooks/use_page_agent.dart';
import 'package:rolling_intelligence_headband/hooks/use_page_agent_get_data.dart';
import 'package:rolling_intelligence_headband/router/route_tree.dart';
import '../../theme/theme.dart';
import 'intercom/talk_tab.dart';
import 'intercom/tts_tab.dart';

/// Tab 名称常量
const _tabNames = ['对讲', 'TTS'];

class IntercomTab extends StatefulWidget {
  const IntercomTab({super.key});

  @override
  State<IntercomTab> createState() => _IntercomTabState();
}

class _IntercomTabState extends State<IntercomTab>
    with TickerProviderStateMixin {
  late TabController _tabController;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _onTabTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _tabController.animateTo(index);
  }

  /// 切换 Tab（供 AI 和 UI 共用）
  void _switchTab(String tabName) {
    final index = _tabNames.indexOf(tabName);
    if (index == -1) {
      throw Exception('无效的Tab名称：$tabName，可选值："对讲"或"TTS"');
    }
    _onTabTap(index);
  }

  @override
  Widget build(BuildContext context) {
    final theme = ThemeModeSignal.themeColorsSignal.value;
    final cardBgColor = theme.isDark
        ? const Color(0xFF2A2A2A)
        : const Color(0xFFF3F4F6);

    return _AgentScope(
      switchTab: _switchTab,
      selectedIndex: _selectedIndex,
      builder: (pageController) => Scaffold(
        backgroundColor: theme.background,
        extendBodyBehindAppBar: true,
        body: SafeArea(
          child: Column(
            children: [
              // 卡片式 Tab 选择器
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.lg,
                  AppSpacing.md,
                  AppSpacing.lg,
                  AppSpacing.sm,
                ),
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: cardBgColor,
                    borderRadius:
                        BorderRadius.circular(AppSpacing.radiusMedium),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: _CardTabButton(
                          label: '对讲',
                          icon: Icons.mic,
                          isSelected: _selectedIndex == 0,
                          onTap: () => _onTabTap(0),
                          theme: theme,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: _CardTabButton(
                          label: 'TTS',
                          icon: Icons.textsms,
                          isSelected: _selectedIndex == 1,
                          onTap: () => _onTabTap(1),
                          theme: theme,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Tab 内容
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    // TalkDispatchTab 接收 pageController，共享 Agent 控制器
                    TalkDispatchTab(
                      theme: theme,
                      pageController: pageController,
                    ),
                    // TTSTab 接收 pageController，共享 Agent 控制器
                    TTSTab(
                      theme: theme,
                      pageController: pageController,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Agent 作用域组件 - 在 HookWidget 中桥接 StatefulWidget 和 Agent 服务
class _AgentScope extends HookWidget {
  final Widget Function(PageAgentController controller) builder;
  final void Function(String tabName) switchTab;
  final int selectedIndex;

  const _AgentScope({
    required this.builder,
    required this.switchTab,
    required this.selectedIndex,
  });

  @override
  Widget build(BuildContext context) {
    // 页面 Agent 总控
    final pageController = useAgentPage(
      meta: RouteNode.homeTab2,
      greetingMessage: '已进入对讲调度页面，可切换对讲或TTS子Tab',
    );

    // 绑定 AI 工具：切换 Tab
    usePageAgent(
      controller: pageController,
      toolName: 'switchTab',
      executeFn: (params) async {
        final tabName = params?['tabName'] as String?;
        if (tabName == null || tabName.isEmpty) {
          throw Exception('请指定要切换的Tab名称，可选值："对讲"或"TTS"');
        }
        switchTab(tabName);
        return {'success': true, 'message': '已切换到$tabName页面'};
      },
    );

    usePageAgentGetData(pageController, "tabState", () {
      return {
        'currentTab': _tabNames[selectedIndex],
        'currentIndex': selectedIndex,
        'availableTabs': _tabNames,
      };
    }, deps: [selectedIndex]);

    // 通知 AI 页面就绪
    useEffect(() {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) {
          pageController.completeEmptyInit();
        }
      });
      return null;
    }, []);

    return builder(pageController);
  }
}

/// 卡片式 Tab 按钮
class _CardTabButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;
  final ThemeColors theme;

  const _CardTabButton({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    final primaryColor = SpringColors.getMintColor(theme.isDark);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 32,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: isSelected
              ? primaryColor.withValues(alpha: 0.12)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(AppSpacing.radiusSmall),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected ? primaryColor : theme.textSecondary,
              size: 15,
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? primaryColor : theme.textSecondary,
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
