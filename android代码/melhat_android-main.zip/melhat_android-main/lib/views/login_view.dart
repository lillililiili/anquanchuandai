import 'package:flutter/material.dart';
import 'package:rolling_intelligence_headband/api/user.dart';
import 'package:rolling_intelligence_headband/hooks/auto_loading.dart';
import 'package:rolling_intelligence_headband/router/route_tree.dart';
import 'package:rolling_intelligence_headband/store/user_store.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import '../utils/app_logger.dart';

/// 登录页（类似 Vue 的 views/Login.vue）
class LoginView extends HookWidget {
  const LoginView({super.key});

  @override
  Widget build(BuildContext context) {
    final usernameController = useTextEditingController();
    final passwordController = useTextEditingController();
    final errorMessage = useState<String?>(null);

    final userStore = useUserStore();

    // 使用 useAutoLoading 管理 loading 状态（类似 TS 的 useAutoLoading）
    final state = useAutoLoading();

    // 登录处理函数（类似 Vue 的 login 方法）
    Future<void> handleLogin() async {
      // usernameController.text = "admin";
      // passwordController.text = "123admin";

      final username = usernameController.text.trim();
      final password = passwordController.text.trim();

      // 简单验证
      if (username.isEmpty || password.isEmpty) {
        errorMessage.value = '请输入用户名和密码';
        return;
      }

      errorMessage.value = null;

      final res = await state.run(UserApi.login(username, password));

      if (res.isSuccess) {
        await userStore.login(token: res.token);

        try {
          final userProfile = await state.run(UserApi.getUserProfile());
          if (userProfile.isSuccess) {
            await userStore.updateUserInfo(userProfile.user!);
          }
        } catch (e) {
          // Profile fetch failed but login succeeded — continue anyway
          AppLogger.e('getUserProfile error', e);
        }

        // 登录成功，跳转到主页
        if (context.mounted) {
          context.replace(RouteNode.homeTab1);
        }
      } else {
        errorMessage.value = res.msg.isNotEmpty ? res.msg : '登录失败';
      }
    }

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo 区域
                Icon(
                  Icons.flutter_dash,
                  size: 80,
                  color: Theme.of(context).primaryColor,
                ),
                const SizedBox(height: 16),
                Text(
                  '智能分体式安全帽',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '欢迎登录',
                  style: Theme.of(
                    context,
                  ).textTheme.bodyLarge?.copyWith(color: Colors.grey[600]),
                ),
                const SizedBox(height: 48),

                // 登录表单
                Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      children: [
                        // 用户名输入框
                        TextField(
                          controller: usernameController,
                          decoration: InputDecoration(
                            labelText: '用户名',
                            prefixIcon: const Icon(Icons.person_outline),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 16),

                        // 密码输入框
                        TextField(
                          controller: passwordController,
                          decoration: InputDecoration(
                            labelText: '密码',
                            prefixIcon: const Icon(Icons.lock_outline),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          obscureText: true,
                          textInputAction: TextInputAction.done,
                          onSubmitted: (_) => handleLogin(),
                        ),

                        // 错误提示
                        if (errorMessage.value != null) ...[
                          const SizedBox(height: 16),
                          Text(
                            errorMessage.value!,
                            style: const TextStyle(color: Colors.red),
                          ),
                        ],

                        const SizedBox(height: 24),

                        // 登录按钮
                        SizedBox(
                          width: double.infinity,
                          height: 48,
                          child: ElevatedButton(
                            onPressed: state.loading ? null : handleLogin,
                            style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: state.loading
                                ? const SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text(
                                    '登录',
                                    style: TextStyle(fontSize: 16),
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
