import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:rolling_intelligence_headband/router/route_tree.dart';
import 'package:rolling_intelligence_headband/views/tabs/intercom_tab.dart';
import 'package:rolling_intelligence_headband/views/tabs/mine_tab.dart';
import 'package:rolling_intelligence_headband/views/tabs/monitor_tab.dart';
import 'package:go_router/go_router.dart';
import '../router/app_router.dart';
import 'tabs/home_tab.dart';

/// 主页（包含底部导航栏）
class HomeView extends StatelessWidget {
  final Widget child;

  const HomeView({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // 主体内容（已经有 Scaffold）
          child,
          // 底部悬浮导航栏（使用 Align 定位）
          Align(
            alignment: Alignment.bottomCenter,
            child: const _NavigationBar(),
          ),
        ],
      ),
    );
  }
}

/// 适配 go_router 17.1.0 的底部导航栏
/// 底部导航栏（悬浮胶囊 + 毛玻璃效果）
class _NavigationBar extends StatefulWidget {
  const _NavigationBar();

  @override
  State<_NavigationBar> createState() => _NavigationBarState();
}

class _NavigationBarState extends State<_NavigationBar> {
  int _currentIndex = 0;
  GoRouter? _router;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 移除旧监听器
    _router?.routeInformationProvider.removeListener(_updateCurrentIndex);
    // 获取新 router 并添加监听器
    _router = GoRouter.of(context);
    _router!.routeInformationProvider.addListener(_updateCurrentIndex);
    _updateCurrentIndex();
  }

  @override
  void dispose() {
    _router?.routeInformationProvider.removeListener(_updateCurrentIndex);
    super.dispose();
  }

  void _updateCurrentIndex() {
    final router = _router;
    if (router == null) return;

    final routePath = router.routeInformationProvider.value.uri.path;

    setState(() {
      if (routePath.contains('/tab1') || routePath == RouteNode.homeTab1.url) {
        _currentIndex = 0;
      } else if (routePath.contains('/tab2') ||
          routePath == RouteNode.homeTab2.url) {
        _currentIndex = 1;
      } else if (routePath.contains('/tab3') ||
          routePath == RouteNode.homeTab3.url) {
        _currentIndex = 2;
      } else if (routePath.contains('/tab4') ||
          routePath == RouteNode.homeTab4.url) {
        _currentIndex = 3;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark
        ? Colors.black.withValues(alpha: 0.1)
        : Colors.white.withValues(alpha: 0.1);

    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            height: 54,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [bgColor, bgColor.withValues(alpha: 0.8)],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.2),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.15),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNavItem(
                  context,
                  index: 0,
                  icon: Icons.home_outlined,
                  selectedIcon: Icons.home,
                  label: '首页',
                ),
                _buildNavItem(
                  context,
                  index: 1,
                  icon: Icons.mic,
                  selectedIcon: Icons.mic,
                  label: '对讲',
                ),
                _buildNavItem(
                  context,
                  index: 2,
                  icon: Icons.monitor,
                  selectedIcon: Icons.monitor,
                  label: '监控',
                ),
                _buildNavItem(
                  context,
                  index: 3,
                  icon: Icons.person_outline,
                  selectedIcon: Icons.person,
                  label: '我的',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(
    BuildContext context, {
    required int index,
    required IconData icon,
    required IconData selectedIcon,
    required String label,
  }) {
    final isSelected = _currentIndex == index;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return InkWell(
      onTap: () {
        final paths = [
          RouteNode.homeTab1.url,
          RouteNode.homeTab2.url,
          RouteNode.homeTab3.url,
          RouteNode.homeTab4.url,
        ];
        setState(() {
          _currentIndex = index;
        });
        context.go(paths[index]);
      },
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: 56,
        padding: const EdgeInsets.symmetric(vertical: 0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 图标区域（固定高度，避免布局跳动）
            SizedBox(
              width: 30,
              height: 30,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // 选中时的圆形毛玻璃背景
                  if (isSelected)
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isDark
                            ? Colors.white.withValues(alpha: 0.2)
                            : Colors.white.withValues(alpha: 0.5),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.4),
                          width: 1,
                        ),
                      ),
                    ),
                  // 图标
                  Icon(
                    isSelected ? selectedIcon : icon,
                    color: isSelected
                        ? Theme.of(context).colorScheme.primary
                        : (isDark ? Colors.white70 : Colors.grey[600]),
                    size: 18,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 9,
                color: isSelected
                    ? Theme.of(context).colorScheme.primary
                    : (isDark ? Colors.white70 : Colors.grey[600]),
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 标签页视图组件
class Tab1View extends StatelessWidget {
  const Tab1View({super.key});

  @override
  Widget build(BuildContext context) {
    return const HomeTabPage();
  }
}

class Tab2View extends StatelessWidget {
  const Tab2View({super.key});

  @override
  Widget build(BuildContext context) {
    return IntercomTab();
  }
}

class Tab3View extends StatelessWidget {
  const Tab3View({super.key});

  @override
  Widget build(BuildContext context) {
    return MonitorTab();
  }
}

class Tab4View extends StatelessWidget {
  const Tab4View({super.key});

  @override
  Widget build(BuildContext context) {
    return MineTabPage();
  }
}
