package com.ruoyi.melhat.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.R;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.headband.pojo.vo.ResponseVO;
import com.ruoyi.helmet.pojo.po.IntercomRecord;
import com.ruoyi.helmet.pojo.po.IntercomRecordRequest;
import com.ruoyi.helmet.service.IIntercomRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * <p>
 * 对讲记录表 前端控制器
 * </p>
 *
 * @author autoGennerate
 * @since 2026-03-12
 */
@RestController
@RequestMapping("/hat/intercom/record")
@Api(tags = "对讲记录接口")
public class IntercomRecordController extends BaseController {
    @Autowired
    private IIntercomRecordService intercomRecordService;

    /**
     * 分页查询对讲记录（支持条件过滤）
     */
    @GetMapping("/page")
    @ApiOperation(value = "对讲记录列表（分页）")
    public R<IPage<IntercomRecord>> getPage(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String intercomType,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Date startTimeFrom,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Date startTimeTo
    ) {
        IPage<IntercomRecord> intercomRecordIPage= intercomRecordService.pageWithFilter(current, size, intercomType, startTimeFrom, startTimeTo);
        return R.ok(intercomRecordIPage);
    }

    /**
     * 根据ID获取对讲记录详情
     */
    @GetMapping("/{id}")
    @ApiOperation(value = "根据ID获取对讲记录详情")
    public R<IntercomRecord> getById(@PathVariable Integer id) {
         intercomRecordService.getById(id);
         return  R.ok();
    }

    /**
     * 结束对讲
     */
    @PutMapping("/end")
    @ApiOperation(value = "结束对讲")
    public R end(@RequestBody IntercomRecord record) throws Exception {
         intercomRecordService.endIntercom(record.getId());
         return  R.ok();
    }


    /**
     * 结束对讲
     */
    @PutMapping("/agoraEnd")
    @ApiOperation(value = "声网结束对讲")
    public R agoraEnd(@RequestBody String channel) throws Exception {
        ResponseVO responseVO = intercomRecordService.endIntercom(channel);
        return  R.ok(responseVO);
    }

    /**
     * 逻辑删除对讲记录
     */
    @DeleteMapping("/{id}")
    @ApiOperation(value = "逻辑删除对讲记录")
    public R delete(@PathVariable Long id) {
         intercomRecordService.deleteById(id);
         return  R.ok();
    }

    /**
     * 快捷创建单呼
     */
    @PostMapping("/single-call")
    @ApiOperation(value = "创建单呼")
    public R<Object> createSingleCall(@RequestBody IntercomRecordRequest request) throws Exception {
        IntercomRecord record = new IntercomRecord();
        record.setIntercomType("01");
        if(StringUtils.isBlank(request.getHatNumber())){
            throw new ServiceException("安全帽编号不能是空");
        }
        if(StringUtils.isBlank(request.getParticipant())){
            throw new ServiceException("呼叫人员不能是空");
        }
        ResponseVO responseVO = intercomRecordService.createIntercom(record, request);
        return  R.ok(responseVO.getData());
    }

    /**
     * 快捷创建群呼
     */
    @PostMapping("/group-call")
    @ApiOperation(value = "创建群呼")
    public R<Object> createGroupCall(@RequestBody IntercomRecordRequest request) throws Exception {
        IntercomRecord record = new IntercomRecord();
        record.setIntercomType("02");
        if(StringUtils.isBlank(request.getHatNumber())){
            throw new ServiceException("安全帽编号不能是空");
        }
        if(StringUtils.isBlank(request.getParticipant())){
            throw new ServiceException("呼叫人员不能是空");
        }
        ResponseVO responseVO = intercomRecordService.createIntercom(record,request);
         return R.ok(responseVO.getData());
    }

    /**
     * 快捷创建组呼
     */
    @PostMapping("/team-call")
    @ApiOperation(value = "创建组呼")
    public R<Object> createTeamCall(@RequestBody IntercomRecordRequest request) throws Exception {
        IntercomRecord record = new IntercomRecord();
        record.setIntercomType("03");
        if(StringUtils.isBlank(request.getGroupId())){
            throw new ServiceException("组呼编号不能是空");
        }
        ResponseVO responseVO =intercomRecordService.createIntercom(record,request);
        return  R.ok(responseVO.getData());
    }
}
