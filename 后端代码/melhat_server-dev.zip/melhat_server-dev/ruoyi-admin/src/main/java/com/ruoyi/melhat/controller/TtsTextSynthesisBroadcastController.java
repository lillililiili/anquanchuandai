package com.ruoyi.melhat.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.R;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.headband.service.HeadbandService;
import com.ruoyi.helmet.pojo.po.TtsRequest;
import com.ruoyi.helmet.pojo.po.TtsTextSynthesisBroadcast;
import com.ruoyi.helmet.service.ITtsTextSynthesisBroadcastService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;

import java.util.Date;

/**
 * <p>
 * TTS文字语音合成广播记录表 前端控制器
 * </p>
 *
 * @author autoGennerate
 * @since 2026-03-12
 */
@RestController
@RequestMapping("/hat/tts/broadcast")
@Api(tags = "TTS文字语音合成广播记录接口")
public class TtsTextSynthesisBroadcastController extends BaseController {
    @Autowired
    private ITtsTextSynthesisBroadcastService broadcastRecordService;

    /**
     * 分页查询广播记录（支持条件过滤）
     */
    @GetMapping("/page")
    @ApiOperation(value = "分页查询广播记录")
    public R<IPage<TtsTextSynthesisBroadcast>> getPage(
            @RequestParam(defaultValue = "1") int current,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String broadcastType,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Date sendTimeFrom,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Date sendTimeTo
    ) {
        IPage<TtsTextSynthesisBroadcast> ttsTextSynthesisBroadcastIPage = broadcastRecordService.pageWithFilter(current, size, broadcastType, sendTimeFrom, sendTimeTo);
        return R.ok(ttsTextSynthesisBroadcastIPage);
    }

    /**
     * 根据ID获取广播记录详情
     */
    @GetMapping("/{id}")
    @ApiOperation(value = "根据ID获取广播记录详情")
    public R<TtsTextSynthesisBroadcast> getById(@PathVariable Long id) {
        TtsTextSynthesisBroadcast ttsTextSynthesisBroadcast = broadcastRecordService.getById(id);
        return R.ok(ttsTextSynthesisBroadcast);
    }

    /**
     * 逻辑删除广播记录
     */
    @DeleteMapping("/{id}")
    @ApiOperation(value = "逻辑删除广播记录")
    public R delete(@PathVariable Long id) {
        broadcastRecordService.deleteById(id);
        return R.ok();
    }

    /**
     * 快捷创建单播
     */
    @PostMapping("/single-broadcast")
    @ApiOperation(value = "创建单播")
    public R createSingleBroadcast(@RequestBody TtsRequest request) throws Exception {
        TtsTextSynthesisBroadcast record = new TtsTextSynthesisBroadcast();
        record.setBroadcastType("01");
        if(StringUtils.isBlank(request.getHatNumber())){
            throw new ServiceException("安全帽编号不能是空");
        }
        if(StringUtils.isBlank(request.getParticipant())){
            throw new ServiceException("呼叫人员不能是空");
        }
        broadcastRecordService.createSingleBroadcast(record,request);
        return R.ok();
    }

    /**
     * 快捷创建群播
     */
    @PostMapping("/group-broadcast")
    @ApiOperation(value = "创建群播")
    public R createGroupBroadcast(@RequestBody TtsRequest request) throws Exception {
        TtsTextSynthesisBroadcast record = new TtsTextSynthesisBroadcast();
        record.setBroadcastType("02");
        if(StringUtils.isBlank(request.getHatNumber())){
            throw new ServiceException("安全帽编号不能是空");
        }
        if(StringUtils.isBlank(request.getParticipant())){
            throw new ServiceException("呼叫人员不能是空");
        }
        broadcastRecordService.createBroadcast(record,request);
        return  R.ok();
    }

    /**
     * 快捷创建组播
     */
    @PostMapping("/team-broadcast")
    @ApiOperation(value = "创建组播")
    public R createTeamBroadcast(@RequestBody TtsRequest request) throws Exception {
        TtsTextSynthesisBroadcast record = new TtsTextSynthesisBroadcast();
        record.setBroadcastType("03");
        if(StringUtils.isBlank(request.getGroupId())){
            throw new ServiceException("组呼编号不能是空");
        }
        broadcastRecordService.createBroadcast(record,request);
        return R.ok();
    }
}
